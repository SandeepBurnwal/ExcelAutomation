__author__ = "sandeep.burnwal"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["sandeep.burnwal"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "sandeep.burnwal"
__email__ = "sandeep_burnwal@bat.com"
__status__ = "Development"

import os
from app import app
from layouts import layout_sidepanel
import callbacks

app.title = 'Pricing Simulator'
app.layout = layout_sidepanel.layout

if __name__ == '__main__':
    app.run_server(host="0.0.0.0", port=8050)
    #app.run_server(debug=False, port=8050)
      
      