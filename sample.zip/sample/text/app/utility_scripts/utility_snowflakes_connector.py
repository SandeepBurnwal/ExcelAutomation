__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import os, sys
sys.path.append(os.getcwd())

import snowflake.connector
import pandas as pd
from app import app

''' 
def sf_connect(connector_flag=1):
    """
    Connect function for creating a connection instance to Snowflakes.
    Parameters:
        None
    """
    conn = None # Initiating connector object as None
    # Setting up Snowflakes connection based on application configuration
    if os.environ["ENV"] == "production":
        print('Setting Production based Snowflake Connector')
        if connector_flag==1:
            conn = snowflake.connector.connect(
                        host=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['host'],
                        user=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['user'],
                        password=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['password'],
                        account=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['account'],
                        warehouse=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['warehouse'],
                        database=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['database'],
                        schema=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['schema'],
                        protocol=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['protocol'],
                        # proxy_host=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS']['proxy_host'],
                        # proxy_port=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS']['proxy_port']
            )
        elif connector_flag==2:
            conn = snowflake.connector.connect(
                        host=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['host'],
                        user=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['user'],
                        password=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['password'],
                        account=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['account'],
                        warehouse=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['warehouse'],
                        database=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['database'],
                        schema=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['schema'],
                        protocol=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['protocol'],
                        # proxy_host=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['proxy_host'],
                        # proxy_port=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['proxy_port']
            )
    elif os.environ["ENV"] == "deployment":
        print('Setting Deployment based Snowflake Connector')
        if connector_flag==1:
            conn = snowflake.connector.connect(
                        host=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['host'],
                        user=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['user'],
                        password=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['password'],
                        account=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['account'],
                        warehouse=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['warehouse'],
                        database=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['database'],
                        schema=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['schema'],
                        protocol=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND']['protocol']
            )
        elif connector_flag==2:
            conn = snowflake.connector.connect(
                        host=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['host'],
                        user=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['user'],
                        password=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['password'],
                        account=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['account'],
                        warehouse=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['warehouse'],
                        database=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['database'],
                        schema=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['schema'],
                        protocol=app.server.config['SNOWFLAKE_LOGIN_CREDENTIALS_RAW']['protocol']
            )
    return conn

def sf_fetch_data(conn, query):
    """
    Fetch Data from Snowflakes database based on query fired
    Parameters:
        conn (snowflakes connector instance): snowflake connector object with connection attributes
        query (str): Fetching query
    """
    df_sf_fetch = conn.cursor().execute(query)
    df_fetch = pd.DataFrame.from_records(iter(df_sf_fetch), columns=[x[0] for x in df_sf_fetch.description])
    return df_fetch

if __name__ == "__main__":
    conn = sf_connect()
    #product table
    fetch_query = 'SELECT * FROM ' + 'RUS_DEV_PRICING_OUTBOUND' + '.' + 'MAIN' + '.' + 'MODEL_PRODUCT'
    product_df_sf_fetch = sf_fetch_data(conn=conn, query=fetch_query)
    product_df_sf = pd.DataFrame.from_records(iter(product_df_sf_fetch), columns=[x[0] for x in product_df_sf_fetch.description])
    product_df_sf_uppc = product_df_sf.apply(lambda x: x.astype(str).str.upper())
    print(product_df_sf_uppc)

'''    