__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import os
import re
import json
import shutil
import subprocess
import pandas as pd
import snowflake.connector
from datetime import datetime, date

#region Filtering & Sorting Datatables
operators = [['ge ', '>='],
             ['le ', '<='],
             ['lt ', '<'],
             ['gt ', '>'],
             ['ne ', '!='],
             ['eq ', '='],
             ['contains '],
             ['datestartswith ']]


def split_filter_part(filter_part):
    for operator_type in operators:
        for operator in operator_type:
            if operator in filter_part:
                name_part, value_part = filter_part.split(operator, 1)
                name = name_part[name_part.find('{') + 1: name_part.rfind('}')]

                value_part = value_part.strip()
                v0 = value_part[0]
                if (v0 == value_part[-1] and v0 in ("'", '"', '`')):
                    value = value_part[1: -1].replace('\\' + v0, v0)
                else:
                    try:
                        value = float(value_part)
                    except ValueError:
                        value = value_part

                # word operators need spaces after them in the filter string,
                # but we don't want these later
                return name, operator_type[0].strip(), value

    return [None] * 3

def filtering_sorting_datatable(df_main, filter, sort_by, page_current, page_size):
    filtering_expressions = filter.split(' && ')
    dff = df_main
    for filter_part in filtering_expressions:
        col_name, operator, filter_value = split_filter_part(filter_part)

        if operator in ('eq', 'ne', 'lt', 'le', 'gt', 'ge'):
            # these operators match pandas series operator method names
            dff = dff.loc[getattr(dff[col_name], operator)(filter_value)]
        elif operator == 'contains':
            dff = dff.loc[dff[col_name].str.contains(filter_value)]
        elif operator == 'datestartswith':
            # this is a simplification of the front-end filtering logic,
            # only works with complete fields in standard format
            dff = dff.loc[dff[col_name].str.startswith(filter_value)]

    if len(sort_by):
        dff = dff.sort_values(
            [col['column_id'] for col in sort_by],
            ascending=[
                col['direction'] == 'asc'
                for col in sort_by
            ],
            inplace=False
        )

    page = page_current
    size = page_size
    return dff.iloc[page * size: (page + 1) * size]
#endregion

#region Model Endpoint/Pickle JSON Generation
def generate_jsons():
    """
    This method generates respective jsons which may be required to map the data from backend to frontend and vice
    versa.
    Parameters: 
        None
    Returns: 
        Generates Jsons brand mapper json, pickle mapper json, etc 
    """
    with open(os.path.join('config','config_snowflakes.json')) as config_file:
        snowflake_config = json.load(config_file)

    conn = snowflake.connector.connect(
                    host=snowflake_config['login_credentials_generic']['host'],
                    user=snowflake_config['login_credentials_generic']['user'],
                    password=snowflake_config['login_credentials_generic']['password'],
                    account=snowflake_config['login_credentials_generic']['account'],
                    warehouse=snowflake_config['login_credentials_generic']['warehouse'],
                    database=snowflake_config['login_credentials_generic']['database'],
                    schema=snowflake_config['login_credentials_generic']['schema'],
                    protocol=snowflake_config['login_credentials_generic']['protocol'],
        )
    
    # query="SELECT PERIOD_ENDING_DATE, PROVINCE, BRAND_AGG, BRAND, MANUF, AVE_PRICE_STICK, PROVINCE_PRICE_STICK_4W, PROVINCE_PRICE_STICK_13W FROM DASH_INPUT \
    #     WHERE CONCAT(PROVINCE,'-',BRAND,'-',PERIOD_ENDING_DATE) IN (SELECT CONCAT(PROVINCE,'-',BRAND,'-',MAX(PERIOD_ENDING_DATE)) FROM DASH_INPUT \
    #     GROUP BY PROVINCE,BRAND) ORDER BY PROVINCE" # PRODUCTION
    query="SELECT PERIOD_ENDING_DATE, PROVINCE, BRAND_AGG, BRAND, MANUF, AVE_PRICE_STICK, PROVINCE_PRICE_STICK_4W, PROVINCE_PRICE_STICK_13W FROM DASH_INPUT_SIMULATION \
        WHERE CONCAT(PROVINCE,'-',BRAND,'-',PERIOD_ENDING_DATE) IN (SELECT CONCAT(PROVINCE,'-',BRAND,'-',MAX(PERIOD_ENDING_DATE)) FROM DASH_INPUT_SIMULATION \
        GROUP BY PROVINCE,BRAND) ORDER BY PROVINCE" # TESTING
    df_sf_fetch = conn.cursor().execute(query)
    df_modeldata = pd.DataFrame.from_records(iter(df_sf_fetch), columns=[x[0] for x in df_sf_fetch.description])

    conn.close()

    if os.path.exists(os.path.join('config','config_modelpicklefiles.json')):
        os.remove(os.path.join('config','config_modelpicklefiles.json'))
    
    model_path = os.path.join('config','model_files')
    model_file_list = [f for f in os.listdir(model_path) if os.path.isfile(os.path.join(model_path, f))]

    brand_mapper_dict = None
    try:
        with open(os.path.join('config','mapper_brand.json')) as config_file:
            brand_mapper_dict = json.load(config_file)
    except Exception as ex:
        print("Reading KA Configuration raised an exception: "+str(ex))

    #UNCOMMENT IF MAPPER JSONS NEEDS REFRESH    
    if os.path.exists(os.path.join('config','mapper_brand.json')):
        os.remove(os.path.join('config','mapper_brand.json'))

    # Mapper for Brand
    brand_mapper_dict={}
    for province in df_modeldata['PROVINCE'].unique():
        df_province_brand = df_modeldata.loc[df_modeldata.PROVINCE.isin([province]),:]
        for brand_row in df_province_brand.iterrows():
            brand_name = brand_row[1].BRAND
            # brand_name = re.sub(r"\s+", "", brand_name) # Remove all whitespaces   
            if brand_name not in brand_mapper_dict.keys():
                brand_mapper_dict[brand_name] = brand_row[1].BRAND_AGG
    
    # Write Mapper Jsons
    with open(os.path.join('config','mapper_brand.json'), 'w') as fp:
        json.dump(brand_mapper_dict, fp, indent=4) 
    
    # Model File Prediction
    province_dict={}
    for province in df_modeldata['PROVINCE'].unique():
        brand_dict={}
        df_province_brand = df_modeldata.loc[df_modeldata.PROVINCE.isin([province]),:]
        for brand in df_province_brand['BRAND'].unique():
            model_file_name = ''
            model_mapper_name = province+'_'+brand_mapper_dict[brand]
            model_mapper_name = re.sub(r"\s+", "", model_mapper_name) # Remove all whitespaces 
            # Check Province + KA + Brand Combination
            for model_name in model_file_list:
                if model_name.endswith(model_mapper_name) and model_file_name=='':
                    model_file_name = model_name
            brand_dict[brand] = model_file_name
        province_dict[province] = brand_dict
    
    # Write Model Mapping Json based on Province + Brand Combination
    with open(os.path.join('config','config_modelpicklefiles.json'), 'w') as fp:
        json.dump(province_dict, fp, indent=4)
#endregion

#region Download Selected Models
def download_selected_models():
    """
    This method downloads models from Azure Databricks and store them in a custom
    folder with name created as per the date initiated for model download
    versa.
    Parameters: 
        None
    Returns: 
        Downloads Model Pickle files from Databricks
    """
    with open(os.path.join('config','config_snowflakes.json')) as config_file:
        snowflake_config = json.load(config_file)

    conn = snowflake.connector.connect(
                    host=snowflake_config['login_credentials_generic']['host'],
                    user=snowflake_config['login_credentials_generic']['user'],
                    password=snowflake_config['login_credentials_generic']['password'],
                    account=snowflake_config['login_credentials_generic']['account'],
                    warehouse=snowflake_config['login_credentials_generic']['warehouse'],
                    database=snowflake_config['login_credentials_generic']['database'],
                    schema=snowflake_config['login_credentials_generic']['schema'],
                    protocol=snowflake_config['login_credentials_generic']['protocol'],
        )
    
    query="SELECT * FROM CPO_FINALMODELSELECTION_SIMULATION ORDER BY MODEL_ID"
    df_sf_fetch = conn.cursor().execute(query)
    df_modeldata = pd.DataFrame.from_records(iter(df_sf_fetch), columns=[x[0] for x in df_sf_fetch.description])

    model_folder_path = 'model_files_%s' %(date.today().strftime("%Y_%d_%b"))
    if os.path.exists(model_folder_path):
        shutil.rmtree(model_folder_path)
    os.makedirs(model_folder_path)
    
    for row in df_modeldata.iterrows():
        print("Downloading model file located in %s" %(row[1].DBFS_PATH))
        process = subprocess.Popen(['dbfs', 'cp', 'dbfs:%s' %(row[1].DBFS_PATH.split('/dbfs')[1]), model_folder_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        # print("Output and error from communicate method are: {}, {}".format(stdout, stderr))
        process.wait()
#endregion

if __name__ == '__main__':
    # generate_jsons()
    download_selected_models()
