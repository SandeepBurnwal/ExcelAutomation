__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import os
import ast
import math
import numpy as np
import pandas as pd
import datetime as dt
import calendar as ca
from datetime import date
from dateutil.relativedelta import relativedelta

SYMBOL_REMOVAL=['"','[',']','{','}','predict',':']

#region General Data Transformations
def custom_datepicker(start_date=None, end_date=None):
    """
    This method extracts month list and week list between a custom
    start date and end date
    Parameters: 
        start_date (str): custom start date
        end_date (str): custom_end_date
    Returns: 
        month_list (list, str): List collection of months falling exclusively within
                            custom dates
        week_list (list, str): List collection of weeks falling exclusively within
                            custom dates
    """
    if start_date is not None and end_date is not None:
        start_date = dt.datetime.strptime(start_date, '%Y-%m-%d')
        end_date = dt.datetime.strptime(end_date, '%Y-%m-%d')
        week_list, month_dict=[],{}
        for i in range((end_date - start_date).days):
            day = ca.day_name[(start_date + dt.timedelta(days=i+1)).weekday()]
            if day.__eq__('Monday') and (start_date + dt.timedelta(days=i+1)).weekday() not in week_list:
                week_list.append(start_date + dt.timedelta(days=i+1))

        for date in week_list:
            if (dt.datetime(date.year,date.month,1)) in month_dict.keys():
                month_dict[dt.datetime(date.year,date.month,1)].append(date)
            else:
                month_dict[dt.datetime(date.year,date.month,1)] = [date]

        # For input structure, Converting week list to specific format
        week_list_input = [i.strftime("%Y-%b-%d") for i in week_list]
        # month_list_input=[month.split('-')[2]+'-'+ for month in month_dict.keys()]
        month_list_input = [i.strftime("%Y-%b-%d") for i in month_dict.keys()]

        return month_list_input, week_list_input
#endregion

#region Custom Benchmarking
def custom_benchmarking(**kwargs):
    """
    This method benchmarks the predictions and lets the predicitons to be constraint to certain
    change (By Default +/- 5% is expected if not overridden)
    Parameters: 
        kwargs : Multiple Arguments
            prediction_output_df (pandas dataframe): predicted dataframe in same order as that of pricing input
            benchmarking_pred_df (pandas dataframe): benchmarking predictions in same order as that of pricing input
            latest_sales_df (pandas dataframe): latest consolidated actual prices and sales data
            pricing_input_df (pandas dataframe): pricing input dataframes
            start_col_index (int): Date Column Starting Index in Prediction Output
            benchmarking_limit (float): Thresholding Limit 
            logger (logging object): Logger
    Returns: 
        modified_prediction_df (pandas dataframe): Benchmarked 
    """
    prediction_output_df = kwargs.get('prediction_output_df')
    benchmarking_pred_df = kwargs.get('benchmarking_pred_df')
    latest_sales_df = kwargs.get('latest_sales_df')
    pricing_input_df = kwargs.get('pricing_input_df')
    start_col_index = kwargs.get('start_col_index')
    benchmarking_limit = kwargs.get('benchmarking_limit') 
    logger = kwargs.get('logger')

    #region Creating benchmarked row predictions
    def create_benchmarking(row_Data=None, 
                            benchmarking_pred_df=benchmarking_pred_df, 
                            latest_sales_df=latest_sales_df,
                            pricing_input_df=pricing_input_df, 
                            start_col_index=start_col_index,
                            benchmarking_limit=benchmarking_limit):
        benchmarked_col_dict = {}
        try:
            # Extract Benchmarking Data
            benchmark_mask = (benchmarking_pred_df.PROVINCE.isin([row_Data.PROVINCE])) & \
                        (benchmarking_pred_df.BRAND.isin([row_Data.BRAND])) & \
                        (benchmarking_pred_df.MANUF.isin([row_Data.MANUF]))
            df_benchmark = benchmarking_pred_df.loc[benchmark_mask].reset_index(drop=True)

            # Extract Pricing Data
            pricing_mask = (pricing_input_df.PROVINCE.isin([row_Data.PROVINCE])) & \
                        (pricing_input_df.BRAND.isin([row_Data.BRAND])) & \
                        (pricing_input_df.MANUF.isin([row_Data.MANUF]))
            df_pricing = pricing_input_df.loc[pricing_mask].reset_index(drop=True)

            # Extract Historic Sales Data
            sales_mask = (latest_sales_df.PROVINCE.isin([row_Data.PROVINCE])) & \
                        (latest_sales_df.BRAND.isin([row_Data.BRAND])) & \
                        (latest_sales_df.MANUF.isin([row_Data.MANUF]))
            df_historic_sales = latest_sales_df.loc[sales_mask].sort_values(by='PERIOD_ENDING_DATE', ascending=False).reset_index(drop=True).head(1)

            start_counter=1
            for colname in row_Data[start_col_index:].index:
                current_price, previous_price=0.0,0.0
                current_prediction, previous_prediction=0.0,0.0
                current_benchmark, previous_benchmark=0.0,0.0
                if start_counter==1:
                    previous_price = round(float(df_historic_sales['AVE_PRICE_STICK'][0] * 20),2) if row_Data.PROVINCE.__eq__('BRITISH COLUMBIA') or row_Data.PROVINCE.__eq__('NEWFOUNDLAND & LABR.') else \
                                    round(float(df_historic_sales['AVE_PRICE_STICK'][0] * 25),2)
                    # Kept equivalent to previous benchmark
                    previous_prediction = float(df_benchmark[df_benchmark.columns[list(df_benchmark.columns).index(colname)-1]][0]) 
                    previous_benchmark = float(df_benchmark[df_benchmark.columns[list(df_benchmark.columns).index(colname)-1]][0])
                    current_price = float(df_pricing[colname][0])
                    current_prediction = float(row_Data[colname])
                    current_benchmark = float(df_benchmark[colname][0])
                else:
                    previous_price = float(df_pricing[df_pricing.columns[list(df_pricing.columns).index(colname)-1]][0])
                    previous_prediction = float(row_Data[row_Data.index[list(row_Data.index).index(colname)-1]])
                    previous_benchmark = float(df_benchmark[df_benchmark.columns[list(df_benchmark.columns).index(colname)-1]][0])
                    current_price = float(df_pricing[colname][0])
                    current_prediction = float(row_Data[colname])
                    current_benchmark = float(df_benchmark[colname][0])
                
                # Logic for Bechmarking
                if (current_price-previous_price)>0 and (current_prediction-previous_prediction)>0:
                    # print('Case1')
                    if (current_benchmark-previous_benchmark)==0:
                        # print('Case1a')
                        benchmarked_col_dict[colname] = min(previous_prediction*(1+(benchmarking_limit/100)), current_prediction)
                    elif (current_benchmark-previous_benchmark)>0:
                        # print('Case1b')
                        if (current_benchmark-previous_prediction)>=0:
                            benchmarked_col_dict[colname] = min(previous_prediction*(1+(benchmarking_limit/100)), current_benchmark, current_prediction)
                        else:
                            benchmarked_col_dict[colname] = min(previous_prediction*(1+(benchmarking_limit/100)), current_prediction)
                    elif (current_benchmark-previous_benchmark)<0:
                        # print('Case1c')
                        if (current_benchmark-previous_prediction)<=0:
                            benchmarked_col_dict[colname] = max(previous_prediction*(1-(benchmarking_limit/100)), current_benchmark)
                        else:
                            benchmarked_col_dict[colname] = previous_prediction*(1-(benchmarking_limit/100))
                    start_counter+=1
                    continue
                elif (current_price-previous_price)<0 and (current_prediction-previous_prediction)<0:
                    # print('Case2')
                    if (current_benchmark-previous_benchmark)==0:
                        # print('Case2a')
                        benchmarked_col_dict[colname] = min(previous_prediction*(1-(benchmarking_limit/100)), current_prediction)
                    elif (current_benchmark-previous_benchmark)>0:
                        # print('Case2b')
                        if (current_benchmark-previous_prediction)<=0:
                            benchmarked_col_dict[colname] = previous_prediction*(1+(benchmarking_limit/100))
                        else:
                            benchmarked_col_dict[colname] = min(previous_prediction*(1+(benchmarking_limit/100)), current_benchmark)
                    elif (current_benchmark-previous_benchmark)<0:
                        # print('Case2c')
                        if (current_benchmark-previous_prediction)<=0:
                            benchmarked_col_dict[colname] = max(previous_prediction*(1-(benchmarking_limit/100)), current_benchmark, current_prediction)
                        else:
                            benchmarked_col_dict[colname] = max(previous_prediction*(1-(benchmarking_limit/100)), current_prediction)
                    start_counter+=1
                    continue
                elif (current_price-previous_price)>0 and (current_prediction-previous_prediction)<0:
                    # print('Case3')
                    benchmarked_col_dict[colname] = max(previous_prediction*(1-(benchmarking_limit/100)), current_prediction)
                    start_counter+=1
                    continue
                elif (current_price-previous_price)<0 and (current_prediction-previous_prediction)>0:
                    # print('Case4')
                    benchmarked_col_dict[colname] = min(previous_prediction*(1+(benchmarking_limit/100)), current_prediction)
                    start_counter+=1
                    continue
                elif (current_price-previous_price)<0 and (current_prediction-previous_prediction)==0:
                    # print('Case5')
                    if (current_benchmark-previous_benchmark)>0:
                        # print('Case5a')
                        if (current_benchmark-previous_prediction)<=0:
                            benchmarked_col_dict[colname] = previous_prediction*(1+(benchmarking_limit/100))
                        else:
                            benchmarked_col_dict[colname] = min(previous_prediction*(1+(benchmarking_limit/100)), current_benchmark)
                    elif (current_benchmark-previous_benchmark)<=0:
                        # print('Case5b')
                        benchmarked_col_dict[colname] = current_prediction
                    start_counter+=1
                    continue
                elif (current_price-previous_price)>0 and (current_prediction-previous_prediction)==0:
                    # print('Case6')
                    if (current_benchmark-previous_benchmark)<0:
                        # print('Case6a')
                        if (current_benchmark-previous_prediction)<=0:
                            benchmarked_col_dict[colname] = max(previous_prediction*(1-(benchmarking_limit/100)), current_benchmark)
                        else:
                            benchmarked_col_dict[colname] = previous_prediction*(1-(benchmarking_limit/100))
                    elif (current_benchmark-previous_benchmark)>=0:
                        # print('Case6b')
                        benchmarked_col_dict[colname] = current_prediction
                    start_counter+=1
                    continue
                elif (current_price-previous_price)==0:
                    # print('Case7, Case8 and Case9' )
                    if (current_benchmark-previous_benchmark)==0:
                        # print('Case7')
                        benchmarked_col_dict[colname] = previous_prediction
                    elif (current_benchmark-previous_benchmark)>0:
                        # print('Case8')
                        if (current_benchmark-previous_prediction)<=0:
                            benchmarked_col_dict[colname] = previous_prediction*(1+(benchmarking_limit/100))
                        else:
                            benchmarked_col_dict[colname] = min(previous_prediction*(1+(benchmarking_limit/100)), current_benchmark)
                    elif (current_benchmark-previous_benchmark)<0:
                        # print('Case9')
                        if (current_benchmark-previous_prediction)>=0:
                            benchmarked_col_dict[colname] = previous_prediction*(1-(benchmarking_limit/100))
                        else:
                            benchmarked_col_dict[colname] = max(previous_prediction*(1-(benchmarking_limit/100)), current_benchmark)
                    start_counter+=1
                    continue
        except Exception:
            pass
        finally:
            return benchmarked_col_dict
    #endregion End of benchmarking row predictions

    modified_prediction_df=prediction_output_df.copy()
    if prediction_output_df is not None and benchmarking_pred_df is not None and \
    latest_sales_df is not None and pricing_input_df is not None:
        for row_Index, row_Data in prediction_output_df.iterrows():
            try:
                benchmarked_col_dict = create_benchmarking(row_Data=row_Data)
                for colname in prediction_output_df.columns[start_col_index:]:
                    modified_prediction_df.iloc[row_Index, prediction_output_df.columns.get_loc(colname)] = benchmarked_col_dict[colname]
                logger.info('Benchmarking Done Successfully for Province: %s and Brand: %s' %(str(row_Data.PROVINCE), str(row_Data.BRAND)))
            except Exception as ex:
                logger.error('Benchmarking Caught exception for Province: %s and Brand: %s' %(str(row_Data.PROVINCE), str(row_Data.BRAND)))
                continue
        return modified_prediction_df      
    else:
        return prediction_output_df.copy()
#endregion

#region Custom Formatter
def custom_formatter(**kwargs):
    """
    This method is utilize to convert each prediction per brand into a customized string format
    Parameters: 
        kwargs : Multiple Arguments
            prediction_output_df (pandas dataframe): predicted dataframe in same order as that of pricing input
            start_col_index (int): Data Column Starting Index in Prediction Output
            before_decimal_approximation (int): How many decimals to round up if predictions are to be expressed in 
                                                exponential form
            make_exponential (bool): True or False (by default False)
            logger (logging object): Logger
    Returns: 
        modified_prediction_df (pandas dataframe): predicted dataframe in with string formatted data
                                                e.g. by default the predictions are represented as exponential form
                                                with a limitation of how many digits needs to be present before decimal
    """
    prediction_output_df = kwargs.get('prediction_output_df')
    start_col_index = kwargs.get('start_col_index')
    before_decimal_approximation = kwargs.get('before_decimal_approximation')
    make_exponential = kwargs.get('make_exponential') if 'make_exponential' in kwargs.keys() else False
    logger = kwargs.get('logger')

    #region Custom Formatter
    def isfloat(value):
        try:
            float(value)
            return True
        except ValueError:
            return False
        
    def format_predictions(row_data=None,
                           start_col_index=start_col_index,
                           before_decimal_approximation=before_decimal_approximation):
        formatted_col_dict = {}
        try:
            predictions = [row_data[predicted_date] for predicted_date in list(row_data[start_col_index:].index)]
            n = before_decimal_approximation
            col_counter = 0
            for prediction in predictions:
                modified_prediction = None 
                current_predicition = prediction               
                if isfloat(current_predicition):
                    current_predicition = current_predicition/1000 # Express the scale of predictions as per thousand sticks
                    if make_exponential:
                        e = math.ceil(math.log10(current_predicition) - n)
                        n_digits = current_predicition * 10**-e
                        if e:
                            modified_prediction = '%.0fe%d' % (n_digits, e)
                        else:
                            modified_prediction = '%.0f' % (current_predicition)
                    else:
                        modified_prediction = round(current_predicition,0)
                else:
                    modified_prediction = prediction

                if row_data[start_col_index:].index[col_counter] not in formatted_col_dict.keys():
                    formatted_col_dict[row_data[start_col_index:].index[col_counter]] = modified_prediction
                
                col_counter+=1
        except Exception: 
            pass
        finally:
            return formatted_col_dict
    #endregion

    modified_prediction_df=prediction_output_df.copy()
    if prediction_output_df is not None:
        for row_Index, row_Data in prediction_output_df.iterrows():
            try:
                formatted_col_dict = format_predictions(row_data=row_Data)
                for colname in prediction_output_df.columns[start_col_index:]:
                    modified_prediction_df.iloc[row_Index, prediction_output_df.columns.get_loc(colname)] = formatted_col_dict[colname]
                logger.info('Custom Formatting Done Successfully for Province: %s and Brand: %s' %(str(row_Data.PROVINCE), str(row_Data.BRAND)))
            except Exception as ex:
                logger.error('Custom Formatting Caught exception for Province: %s and Brand: %s with exception as %s' %(str(row_Data.PROVINCE), str(row_Data.BRAND), str(ex)))
                continue
        return modified_prediction_df  
    else:
        return prediction_output_df.copy()
#endregion

#region Prediction Compiler
def compile_prediction(**kwargs):
    """
    This method compiles prediciton output based on 3 types of granularity:
    1. Weekly
    2. Annually i.e. Monthly
    3. Custom expressed as extension of Weekly
    Parameters: 
        kwargs : Multiple Arguments
            period_type (str): type of granularity (options are weekly, annually and custom)
            predicted_data (str): string response from model service
            result_df (pandas dataframe): Dataframe Framework to fill in details
            row_data (pandas series): provides information on some extra colums 
            column_name_list (list, str): list of column names to iterate on
            month2weeks (list, str): List of all available weeks within simualtion period i.e.  Monday of each week
            take_log (bool): If log needs to be taken or not based on type of model
            error (bool): if its an error predicted data or successful one
    Returns: 
        result_df (pandas dataframe): Dataframe Framework Aggregated Properly with prediction
    """
    period_type = kwargs.get('period_type')
    predicted_data = kwargs.get('predicted_data')
    result_df = kwargs.get('result_df')
    row_data = kwargs.get('row_data')
    column_name_list = kwargs.get('column_name_list')
    month2weeks = kwargs.get('month2weeks')
    take_log = kwargs.get('take_log')
    error = kwargs.get('error')

    if not error:
        # Cleaning Predicted Message
        for item in SYMBOL_REMOVAL:
            predicted_data = predicted_data.replace(item,'')
        result = ast.literal_eval(predicted_data.strip())

        # Check if models used are log-linear models
        if take_log:
            result = tuple([np.expm1(item) for item in result])
            if any(math.isinf(prediction) for prediction in result):
                modified_result = []
                for prediction in result:
                    modified_result.append(0.0) if math.isinf(prediction) else modified_result.append(prediction)
                result = tuple(modified_result)
            # if all(prediction == result[0] for prediction in result) and math.isinf(result[0]):
            #     result = tuple([0.0 for i in range(len(result))])

        if period_type.__eq__('Quarterly') or period_type.__eq__('Custom'):
            if isinstance(result, tuple):
                result_df.loc[0] = column_name_list+list(result)
                return result_df
        elif period_type.__eq__('Annually'):
            if isinstance(result, tuple):
                # Perform Avg Aggregation for converting weekly level predictions
                # to month level data
                month_map, month_agg={},{}
                predicted_list, extraction_counter = list(result), 0
                iterative_list = list(result_df.columns[3:]) 
                for item in iterative_list:
                    try:
                        item_year_month = '-'.join(item.split('-')[0:2])
                        month_map[item_year_month] = [x for x in month2weeks if '-'.join(x.split('-')[0:2]) == item_year_month]
                        if len(month_map[item_year_month])>0:
                            agg_predicted_list = predicted_list[extraction_counter:(extraction_counter+len(month_map[item_year_month]))]
                            month_agg[item] = round(sum(agg_predicted_list),2)
                            extraction_counter+=len(month_map[item_year_month])
                    except Exception:
                        month_agg[item] = 'Aggregation Error'
                        continue
                result_df.loc[0] = column_name_list+list(month_agg.values())
                return result_df
    else:
        if isinstance(predicted_data, str):
            result_df.loc[0] = [row_data.PROVINCE, row_data.BRAND, row_data.MANUF]+[predicted_data for i in range(len(result_df.columns)-3)]
            return result_df

def compile_moving_average(**kwargs):
    """
    This method compiles prediciton output based on 3 types of granularity:
    1. Quarterly i.e. Weekly
    2. Annually i.e. Monthly
    3. Custom expressed as extension of Weekly
    Parameters: 
        kwargs : Multiple Arguments
            period_type (str): type of granularity (options are weekly, annually and custom)
            prediction_output_df (str): string response from model service
            latest_sales_df (pandas dataframe): Dataframe Framework to fill in details
            month2weeks (list, str): List of all available weeks within simualtion period i.e.  Monday of each week
            logger (logging object): Logger
    Returns: 
        result_df (pandas dataframe): Dataframe Framework Aggregated Properly with moving average treatment
    """
    period_type = kwargs.get('period_type')
    prediction_output_df = kwargs.get('prediction_output_df')
    latest_sales_df = kwargs.get('latest_sales_df')
    month2weeks = kwargs.get('month2weeks')
    logger = kwargs.get('logger')

    def extract_moving_average(row_data=None,
                               period_type=period_type,
                               sales_df=latest_sales_df.copy(),
                               month2weeks=month2weeks):
        movingavg_col_dict={}
        try:
            # Apply Province and Brand filter to get only specific data
            sales_mask = (sales_df.PROVINCE.isin([row_data.PROVINCE])) & (sales_df.BRAND.isin([row_data.BRAND]))
            sales_df = sales_df.loc[sales_mask]
            # Adding Predicted Volumes to sales data
            month_map={}
            for date_col in row_data.index[3:]:
                if period_type.__eq__('Quarterly') or period_type.__eq__('Custom'):
                    sales_df = sales_df.append({
                                        'PERIOD_ENDING_DATE': pd.to_datetime(date_col).date(),
                                        'PROVINCE': row_data.PROVINCE,
                                        'BRAND': row_data.BRAND,
                                        'POS_SALES_QUANTITY_STICKS': row_data[date_col]
                                    }, ignore_index=True)
                elif period_type.__eq__('Annually'):
                    item_year_month = '-'.join(date_col.split('-')[0:2])
                    month_map[item_year_month] = [x for x in month2weeks if '-'.join(x.split('-')[0:2]) == item_year_month]
                    if len(month_map[item_year_month])>0:
                        for week in month_map[item_year_month]:
                            sales_df = sales_df.append({
                                            'PERIOD_ENDING_DATE': pd.to_datetime(week).date(),
                                            'PROVINCE': row_data.PROVINCE,
                                            'BRAND': row_data.BRAND,
                                            'POS_SALES_QUANTITY_STICKS': row_data[date_col]/len(month_map[item_year_month])
                                        }, ignore_index=True)
            # Sorting out based on sales date
            sales_df = sales_df.sort_values(by='PERIOD_ENDING_DATE', ascending=True).reset_index(drop=True)
            # Get Moving Average
            sales_df['VOL_MOVING_AVERAGE'] = sales_df['POS_SALES_QUANTITY_STICKS'].transform(lambda x: x.rolling(52, 1).mean()) if period_type.__eq__('Annually') else \
                                            sales_df['POS_SALES_QUANTITY_STICKS'].transform(lambda x: x.rolling(12, 1).mean())
            
            # Extract Moving Averages 
            for date_col in row_data.index[3:]:
                try:
                    if period_type.__eq__('Quarterly') or period_type.__eq__('Custom'):
                        if date_col not in movingavg_col_dict.keys():
                            movingavg_col_dict[date_col] = sales_df.loc[sales_df.PERIOD_ENDING_DATE.isin([pd.to_datetime(date_col).date()])].reset_index(drop=True)['VOL_MOVING_AVERAGE'][0]
                    elif period_type.__eq__('Annually'):
                        if date_col not in movingavg_col_dict.keys():
                            item_year_month = '-'.join(date_col.split('-')[0:2])
                            month_level_week_list =  [pd.to_datetime(x).date() for x in month2weeks if '-'.join(x.split('-')[0:2]) == item_year_month]
                            monthly_sales = sales_df.loc[sales_df.PERIOD_ENDING_DATE.isin(month_level_week_list)].reset_index(drop=True)['VOL_MOVING_AVERAGE'].sum()
                            movingavg_col_dict[date_col] = monthly_sales
                except Exception:
                    continue
        except Exception as ex:
            print(ex)
            pass
        finally:
            return movingavg_col_dict

    df_intermediate_predicted = prediction_output_df.copy()
    if len(prediction_output_df)>0 and len(latest_sales_df)>0:
        for row_index, row_data in prediction_output_df.iterrows():
            try:
                movingavg_col_dict=extract_moving_average(row_data=row_data)
                for colname in prediction_output_df.columns[3:]:
                    if isinstance(prediction_output_df.iloc[row_index, prediction_output_df.columns.get_loc(colname)], float) and \
                    prediction_output_df.iloc[row_index, prediction_output_df.columns.get_loc(colname)]<=0:
                        df_intermediate_predicted.iloc[row_index, prediction_output_df.columns.get_loc(colname)] = movingavg_col_dict[colname] if colname in movingavg_col_dict.keys() else 0.0
            except Exception as ex:
                logger.error('Moving Average Treatment Caught exception for Province: %s and Brand: %s' %(str(row_data.PROVINCE), str(row_data.BRAND)))
                continue 

    return df_intermediate_predicted
#endregion

#region Baseline Predicitons
def perform_base_simulation(**kwargs):
    """
    This method performs baseline predictions with default data and also performs cross checks
    if base predictions are already existing as weekly as well as monthly granularity
    Parameters: 
        kwargs : Multiple Arguments
            df_historic (pandas dataframe): Stores Historic Consolidated data wrt Province + Brand Combination
            df_consolidated (pandas dataframe): Stores Latest Consolidated data wrt Province + Brand Combination
            df_features (pandas dataframe): Significant Features Dataframe
            df_xvar (pandas dataframe): Variable Values for Significant Features
            df_competitor_rank (pandas dataframe): Competitor rank for Province + Brand Combination
            overridden_xvars_dict (dict, (dict, pandas dataframe)): Dictionary of Overridden xvars which need updation 
                                                                    irrespective of price change
            df_variable_type (pandas dataframe): Stores Variables and their Category and Types
            df_models (pandas dataframe): Model Endpoint Registry Name Dataframe
            model_endpoints_dict (dict, str): Endpoint for Linear, Lasso, Ridge, Elastic Models
            model_picklefiles_dict (dict, str): Model Pickle Mapper wrt Province + Brand Combination
            brand_mapper_dict (dict, str): Mapping of BRAND vs BRAND_AGG
            month_to_weeks (list, str): Month to Week Mapping
            month_range (list, str): Month Mapping          
            logger (logger object): Logger Object for logging operational steps
    Returns: 
        base_predictions_weekly.csv (csv): Stores Baseline Predictions at weekly granularity
        base_predictions_monthly.csv (csv): Stores Baseline Predictions at monthly granularity
    """

    # Module Imported here to break circular dependency
    from tasks import long_running_simulation

    # Retrieve Functional Arguments 
    df_historic=kwargs.get('df_historic')
    df_consolidated=kwargs.get('df_consolidated')
    df_features=kwargs.get('df_features')
    df_xvar=kwargs.get('df_xvar')
    df_competitor_rank=kwargs.get('df_competitor_rank')
    overridden_xvars_dict=kwargs.get('overridden_xvars_dict')
    df_variable_type=kwargs.get('df_variable_type')
    df_models=kwargs.get('df_models')
    model_endpoints_dict=kwargs.get('model_endpoints_dict')
    model_picklefiles_dict=kwargs.get('model_picklefiles_dict')
    brand_mapper_dict=kwargs.get('brand_mapper_dict')
    month_to_weeks=kwargs.get('month_to_weeks')
    month_range=kwargs.get('month_range')          
    logger=kwargs.get('logger')

    # Check for dataset and if base results already exists for next 12 months 
    # on weekly based granularity
    base_weekly_flag, base_monthly_flag = False, False
    if os.path.exists(os.path.join('datasets','base_predictions_weekly.csv')):
        df_base_results=pd.read_csv(os.path.join('datasets','base_predictions_weekly.csv'))
        if list(df_base_results.columns[3:]) == month_to_weeks:
            base_weekly_flag = True
            logger.info('Base Predictions are already available at Weekly Granularity')
        else:
            os.remove(os.path.join('datasets','base_predictions_weekly.csv'))
            logger.info('Older Weekly Base Predictions are removed Successfully')
    if os.path.exists(os.path.join('datasets','base_predictions_monthly.csv')):
        df_base_results=pd.read_csv(os.path.join('datasets','base_predictions_monthly.csv'))
        if list(df_base_results.columns[3:]) == month_range:
            base_monthly_flag = True
            logger.info('Base Predictions are already available at Monthly Granularity')
        else:
            os.remove(os.path.join('datasets','base_predictions_monthly.csv'))
            logger.info('Older Monthly Base Predictions are removed Successfully')
    if base_weekly_flag and base_monthly_flag:
        return

    df_consol_pricing_weekly = df_consolidated.copy()
    df_consol_pricing_weekly = df_consol_pricing_weekly.sort_values(by=['PROVINCE', 'BRAND'], ascending=False)
    df_consol_pricing_weekly = pd.concat([df_consol_pricing_weekly[['PROVINCE','BRAND','MANUF','PRICE_PACK_13W','PRICE_PACK_4W','PRICE_PACK_LATEST']],pd.DataFrame(columns=month_to_weeks)])
    df_consol_pricing_weekly = df_consol_pricing_weekly.ffill(axis = 1)
    logger.info('Base Consolidate Pricing Dataframe Generated with Weekly Granularity')

    df_consol_pricing_monthly = df_consolidated.copy()
    df_consol_pricing_monthly = df_consol_pricing_monthly.sort_values(by=['PROVINCE', 'BRAND'], ascending=False)
    df_consol_pricing_monthly = pd.concat([df_consol_pricing_monthly[['PROVINCE','BRAND','MANUF','PRICE_PACK_13W','PRICE_PACK_4W','PRICE_PACK_LATEST']],pd.DataFrame(columns=month_range)])
    df_consol_pricing_monthly = df_consol_pricing_monthly.ffill(axis = 1)
    logger.info('Base Consolidate Pricing Dataframe Generated with Monthly Granularity')

    if not base_weekly_flag:
        df_predicted_weekly = long_running_simulation(df_historic=df_historic,
                                                    df_consolidated=df_consolidated,
                                                    df_pricing_input=df_consol_pricing_weekly,
                                                    df_features=df_features,
                                                    df_xvar=df_xvar,
                                                    df_competitor_rank=df_competitor_rank,
                                                    overridden_xvars_dict=overridden_xvars_dict,
                                                    df_variable_type=df_variable_type,
                                                    df_model_endpoints=df_models,
                                                    model_endpoints_dict=model_endpoints_dict,
                                                    model_picklefile_dict=model_picklefiles_dict,
                                                    brand_mapper_dict=brand_mapper_dict,
                                                    period_type='Quarterly',
                                                    month_to_weeks=month_to_weeks,
                                                    pickle_flag=True,
                                                    logger=logger)
        
        # Write Prediction Results
        df_predicted_weekly.to_csv(os.path.join('datasets','base_predictions_weekly.csv'), index=False)
        logger.info('Base Predictions at Weekly Granularity are written Successfully')

    if not base_monthly_flag:
        df_predicted_monthly = long_running_simulation(df_historic=df_historic,
                                                    df_consolidated=df_consolidated,
                                                    df_pricing_input=df_consol_pricing_monthly,
                                                    df_features=df_features,
                                                    df_xvar=df_xvar,
                                                    df_competitor_rank=df_competitor_rank,
                                                    overridden_xvars_dict=overridden_xvars_dict,
                                                    df_variable_type=df_variable_type,
                                                    df_model_endpoints=df_models,
                                                    model_endpoints_dict=model_endpoints_dict,
                                                    model_picklefile_dict=model_picklefiles_dict,
                                                    brand_mapper_dict=brand_mapper_dict,
                                                    period_type='Annually',
                                                    month_to_weeks=month_to_weeks,
                                                    pickle_flag=True,
                                                    logger=logger)

        # Write Prediction Results
        df_predicted_monthly.to_csv(os.path.join('datasets','base_predictions_monthly.csv'), index=False)
        logger.info('Base Predictions at Monthly Granularity are written Successfully')
#endregion