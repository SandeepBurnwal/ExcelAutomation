__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import os
import json
import time
import asyncio
import requests  
import snowflake.connector
import pandas as pd
from aiohttp import ClientSession
from requests.exceptions import HTTPError

class GenerateDummyData():
    def __init__(self, model_parameters_dict, no_of_datapoints=1):
        """
        Parameters
            model_parameters_dict(dict, dict of feature len & reg name) : Count of features in each of these models and reg model name
            no_of_datapoints(int) : No of datapoints to be populated 
        """
        self._model_parameters_dict = model_parameters_dict
        self._no_of_datapoint = no_of_datapoints
        
    def generate_input(self):
        data_created={}
        for model in self._model_parameters_dict.keys():
            if model not in data_created.keys():
                data_created[model] = {'data':[[x+no for x in range(1,self._model_parameters_dict[model]['feature_count']+1)] for no in range(self._no_of_datapoint)]}
            data_created[model]['MODEL_REG_NAME'] = self._model_parameters_dict[model]['model_reg_name']
            data_created[model]['MODEL_TYPE'] = self._model_parameters_dict[model]['model_type'].upper()
            data_created[model]['MODEL_ID'] = model
        return data_created
        
class AsyncModelEndpoints():
    def __init__(self, **kwargs):
        """
        Parameters
            **kwargs : url_dict, data_dict, headers
        """
        self.__dict__.update(kwargs)
    
    async def post_data(self, model_dict, session):
        """
        Post Model Endpoint (asynchronously)
        Parameters:
            model_dict (Model Name): name of the model in azure registry file and data embedded
            session (Client Session): session to be asynchronized
        """
        _url_dict = self.__dict__.get("url_dict")
        _headers = self.__dict__.get("headers")
        _url = _url_dict[model_dict["MODEL_TYPE"]] # Modify this step according to your requirement
        _data = json.dumps(
                        {'data': model_dict['data'],
                        'MODEL_REG_NAME': model_dict['MODEL_REG_NAME']}
                    ) # Modify this step according to your requirement

        response = None
        try:
            response = await session.post(url=_url, data=_data, headers=_headers)
            response.raise_for_status()
            print(f"Response status ({_url}): {response.status}")
        except HTTPError as http_err:
            print(f"HTTP error occurred: {http_err}")
        except Exception as err:
            print(f"An error ocurred: {err}")
        response_json = await response.json()
        predictions = response_json
        return predictions 

    async def run_program(self, model_dict, session):
        """
        Python Wrapper for posting data asynchronously
        """
        try:
            response = await self.post_data(model_dict, session)
            print(f"Async Prediction: {len(response)}")
            return {'model_id': model_dict['MODEL_ID'], 'predictions': response}
        except Exception as err:
            print(f"Exception occured: {err}")
            pass

    async def run_async(self):
        """
        Async fucntion to fire simulations
        """
        data_dict = self.__dict__.get('data_dict') # Modify this step according to your requirement
        start_time = time.time()
        async with ClientSession() as session:
            return await asyncio.gather(*[self.run_program(data_dict[model], session) for model in data_dict.keys()])
        print("PREDICTION COMPLETED ASYNCHRONOUSLY IN", time.time() - start_time, "SECONDS")

if __name__ == "__main__":    
    with open(os.path.join('config','config_snowflakes.json')) as config_file:
        snowflake_config = json.load(config_file)

    with open(os.path.join('config','config_modelendpoints.json')) as config_file:
        CONFIG_MODEL_ENDPOINTS = json.load(config_file)

    conn = snowflake.connector.connect(
                    host=snowflake_config['login_credentials_generic']['host'],
                    user=snowflake_config['login_credentials_generic']['user'],
                    password=snowflake_config['login_credentials_generic']['password'],
                    account=snowflake_config['login_credentials_generic']['account'],
                    warehouse=snowflake_config['login_credentials_generic']['warehouse'],
                    database=snowflake_config['login_credentials_generic']['database'],
                    schema=snowflake_config['login_credentials_generic']['schema'],
                    protocol=snowflake_config['login_credentials_generic']['protocol']
        )
    query="SELECT * FROM CPO_FINALMODELSELECTION_KA_PROVINCE_BRAND ORDER BY MODEL_ID LIMIT 10"
    df_sf_fetch=conn.cursor().execute(query)
    df_models=pd.DataFrame.from_records(iter(df_sf_fetch), columns=[x[0] for x in df_sf_fetch.description])

    MODEL_PARAMETERS_DICT={}
    # query="SELECT * FROM CPO_SELECTEDVARS_KA_PROVINCE_BRAND ORDER BY MODEL_ID"
    # df_sf_fetch=conn.cursor().execute(query)
    # df_features=pd.DataFrame.from_records(iter(df_sf_fetch), columns=[x[0] for x in df_sf_fetch.description])
    df_features=pd.read_csv(os.path.join('datasets','CPO_SELECTEDVARS_KA_PROVINCE_BRAND.csv'))
    df_features=df_features.loc[df_features.MODEL_ID.isin(list(df_models.MODEL_ID.unique()))]
    
    for models in df_models.iterrows():
        model_id = models[1].MODEL_ID
        feature_list=df_features.loc[df_features.MODEL_ID.isin([model_id])].XVAR.to_list()
        MODEL_PARAMETERS_DICT[model_id]={
            'feature_count':len(feature_list),
            'model_reg_name':models[1].MODEL_REG_NAME,
            'model_type':models[1].MODEL
        }

    NO_OF_DATAPOINTS_PER_MODEL = 10000

    #region Data Creation Section 
    GENERATE_DUMMY_INSTANCE = GenerateDummyData(
                                    model_parameters_dict = MODEL_PARAMETERS_DICT,
                                    no_of_datapoints = NO_OF_DATAPOINTS_PER_MODEL
                                )
    model_data = GENERATE_DUMMY_INSTANCE.generate_input()
    #endregion
    
    #region Asynchronous Calling of model endpoints
    ASYNC_INSTANCE = AsyncModelEndpoints(
                                    url_dict = CONFIG_MODEL_ENDPOINTS,
                                    data_dict = model_data,
                                    headers = {'Content-Type': 'application/json'}
                                )
    loop = asyncio.get_event_loop()
    future = asyncio.ensure_future(ASYNC_INSTANCE.run_async())
    prediction_list = loop.run_until_complete(future)
    #endregion