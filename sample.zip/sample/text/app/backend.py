__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import os
import re
import ast
import base64
import logging
import pandas as pd
import numpy as np
import json
import requests
import snowflake.connector

from app import app
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta

from config.config_all import api_key, end_point_uri, final_model_col_list

#from utility_scripts.utility_snowflakes_connector import sf_connect, sf_fetch_data
#from utility_scripts.utility_data_transformation import perform_base_simulation, custom_datepicker

baseline_logger = logging.getLogger('baseprediction_handler') # Retrieve Logger Handler

# Connecting to Snowflakes
#conn = sf_connect()
#conn_raw = sf_connect(connector_flag=2)

# Historic SA DATA
#path = 'D:/Project/Cross_market_dash/Documents/sa_elasticity_all'
#path = 'D:/Project/Cross_market_dash/DataScienceSolutions/hub/solutions/marketing/pricing_solutions/brazil/intelli_price/app/datasets'        
#df_snow_data = pd.read_csv(path +'/BR_Price_Simulator_Data.csv')
#print('dtype 1111', df_snow_data.columns)
#print('dtype 2222', df_snow_data.dtypes)

#  Preload loading spinner to base64 encode
spinner = base64.b64encode(open(os.path.join('assets', 'spinner.gif'), 'rb').read())

def data_load_snowflake(login_user, login_password, login_account, data_warehouse, data_query):
    ctx = snowflake.connector.connect(
        user=login_user,
        password=login_password,
        account=login_account,
        warehouse=data_warehouse
        )
    query = data_query
    cur = ctx.cursor().execute(query)
    df = pd.DataFrame.from_records(iter(cur), columns=[x[0] for x in cur.description])
    return(df)
#################################################################################################


## Fetch the Pre-calculated data from Snowflake ..
Pre_calculated = '''
select * from "BRA_DEV_INTEGRATION"."PRI_SIM"."SV_RGM_PRE_CALCULATED";
'''

# select * from "BRA_DEV_DATASCIENCE"."PRI_SIM"."LOAD_RGM_PRICE_SIMULATOR";

df_snow_data = data_load_snowflake(login_user='RGM_BRA_DEV_SERVICE_USER', login_password='9MZeZKa8DktKrHKj',
login_account='fx54096.west-europe.azure', data_warehouse='BRA_DEV_PRESENTATION_ADHOC_WH', data_query=Pre_calculated)

df_snow_data.drop(columns=['SOURCE_SYSTEM', 'INSERT_TS'], axis=1, inplace=True)
df_snow_data.rename(columns={'TOTAL_SALES_VOLUME': 'SALES'}, inplace=True)
df_snow_data['SALES'] = df_snow_data.apply(lambda x: "{:,.0f}".format(x['SALES']), axis=1)   # Formatting with comma 
df_snow_data['YEAR'] = df_snow_data['YEAR'].astype('int64')
df_snow_data['MONTH'] = df_snow_data['MONTH'].astype('int64')
df_snow_data['QUARTER'] = df_snow_data['QUARTER'].astype('int64')
###################################################################################################


# End point testing
def test_post_headers_body_json(input_data):  

    '''  
        # Prediction using the pickle file 
        import os
        import joblib
        os.chdir('D:/Project/Cross_market_dash/DataScienceSolutions/hub/solutions/marketing/pricing_solutions/south_africa/intelli_price/app')
        filename = 'price_simulator_15072021.pkl'
        # load the model from disk
        loaded_model = joblib.load(filename)
        
        # json.loads() -- for the string function ...

        pred_test_old = loaded_model.predict(df_pricing_old)
        pred_test_new = loaded_model.predict(df_pricing_input)
        '''

    token_key = api_key['id']   
    scoring_uri = end_point_uri['rest_api']
    headers = {'Content-Type':'application/json', 'Authorization':('Bearer '+ token_key)}
    
    # To avoid below error, datatype is changed to float .. "TypeError: (Integer) is not JSON serializable" 
    for col in input_data.columns:
        try:
            input_data[col] = input_data[col].astype(float)
        except:
            pass
   
    # Prepare the data for end-point to be triggered ... list of list-records
    input_data = input_data.values.tolist()
    json_dict={
            'data':input_data,
            'model':'price_simulator_br'} # price_simulator_sa        

    final_input_data = json.dumps(json_dict)          
    response = requests.post(scoring_uri, final_input_data, headers=headers) 
    
    predicted_array = response.json() 
    predicted_array = ast.literal_eval(predicted_array) # Response from the end-point api is the string representation of List. Extarcting the entire list
    predicted_array = np.array(predicted_array)   # Next converting the list into a numpy array so as to use further (reshape function
    predicted_array = np.round(predicted_array, 2)

    return predicted_array
###########################################################################


# From the price dataframe passed in argument, categorical col are encoded into dummy variables 
def oneHotEncode(df_all):    
    categorical_Columns = ['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS']
 
    for col in categorical_Columns:
        dummies = pd.get_dummies(df_all[col], prefix=col)
        df_all = pd.concat([df_all, dummies], axis=1)
        
        df_all.drop([col],axis = 1 , inplace=True) #drop the encoded column
    
    return df_all
###########################################################################


# From the price dataframe passed in argument, categorical col are encoded into dummy variables 
def prepare_final_model_price_data(df_price):    
    df_price_empty = pd.DataFrame(columns = final_model_col_list['col_list'])
    
    for i in range(len(df_price)):
        for col in df_price_empty.columns:
            if col in df_price.columns:
                df_price_empty.loc[i, col] = df_price.loc[i, col]
            else:
                df_price_empty.loc[i, col] =  0    

    #df_price.to_csv('df_price_after_encoding.csv')
    #df_price_empty.to_csv('df_price_empty_after_encoding.csv')

    return df_price_empty
###########################################################################


def prepare_price_data_model(df_price):
        
        ''' 
        Step 1 > Create the new price dataframe from callback with user prices | Create the old price dataframe from dcc.Store (Snowflake) 
        Step 2 > Convert the year_month price column into a single column (Values) with all price data using melt function
        Step 3 > Using the price and pack size information from dataframe created in Step 1, update the PRICE_PER_STICK in original dataframe
        Step 4 > Drop the 'Unnamed: 0' col from original dataframe
        Step 5 > Drop 'Price_per_pack', 'Value' from both New + Old price dataframe created in Step 1
        Step 6 > Merge New + Old dataframe with Original so as to take reamaining 30+ features required for trigerring the model
        '''
        
        df_price_all = pd.DataFrame()
        for i in range(len(df_price)):        

            # Extract the one complete row and do the transformation. Later the dataframe is merged into one
            df_price_row = df_price.iloc[[i],:]
            df_price_row = df_price_row.melt(id_vars=['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS'], var_name="AVG_PRICE_20", value_name="Value")       
            df_price_row.rename(columns={'AVG_PRICE_20': 'YEAR', 'Value': 'AVG_PRICE_20'}, inplace=True)
            df_price_row['YEAR'] = [x[:4] for x in df_price_row['YEAR']]

            df_price_all = pd.concat([df_price_all, df_price_row], ignore_index=True)

        df_price = oneHotEncode(df_price_all) # Encoding using above function
        df_price_empty = prepare_final_model_price_data(df_price)  # Take the original list of encoded columns the model expects, and then match it with the new test records columns 
        return df_price_empty

####################################################################################################


def prepare_price_output_data(df_pricing_new_output, pred_test_new, df_pricing_old_output, pred_test_old):
                
        # First Output Structure with all columns with flattened Month_Year data ''                
        ############################################################################################
        df_sales_output_common_col, df_sales_month_col = df_pricing_new_output.copy(), df_pricing_old_output.copy()              
        df_sales_month_col.drop(['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS'], axis = 1, inplace=True)
        
        label_old = pred_test_old.reshape(int((len(pred_test_old)/9)), 9)
        label_new = pred_test_new.reshape(int((len(pred_test_new)/9)), 9)

        label_old_df = pd.DataFrame(label_old, columns=df_sales_month_col.columns)
        label_new_df = pd.DataFrame(label_new, columns=df_sales_month_col.columns)

        df_sales_output_new = df_sales_output_common_col.merge(label_new_df, left_index=True, right_index=True, how='left', suffixes=('_DROP', '')).filter(regex='^(?!.*_DROP)')
        df_sales_output_new['Price_Type'] = 'New Price'

        df_sales_output_old = df_sales_output_common_col.merge(label_old_df, left_index=True, right_index=True, how='left', suffixes=('_DROP', '')).filter(regex='^(?!.*_DROP)')
        df_sales_output_old['Price_Type'] = 'Old Price'       
        df_pricing_combined_volume_output_1 = pd.concat([df_sales_output_new, df_sales_output_old])    

        # Second Output Structure with all columns ''
        ############################################################################################
        df_pricing_new_output = df_pricing_new_output.melt(id_vars=['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS'], var_name="AVG_PRICE_20", value_name="Value")
        df_pricing_new_output['Volume'] = pred_test_new # Assign the new predictions to the volume variable, renaming is required
        df_pricing_new_output['Price_Type'] = 'New Price'
        df_pricing_new_output.rename(columns = {'AVG_PRICE_20':'Period', 'Value':'AVG_PRICE_20'}, inplace = True)

        df_pricing_old_output = df_pricing_old_output.melt(id_vars=['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS'], var_name="AVG_PRICE_20", value_name="Value")
        df_pricing_old_output['Volume'] = pred_test_old # Assign the new predictions to the volume variable, renaming is required
        df_pricing_old_output['Price_Type'] = 'Old Price'
        df_pricing_old_output.rename(columns = {'AVG_PRICE_20':'Period', 'Value':'AVG_PRICE_20'}, inplace = True)

        df_pricing_combined_volume_output_2 = pd.concat([df_pricing_new_output, df_pricing_old_output])               
        # df_pricing_combined_volume_output_2['Volume'] = correct_price_elasticity(df_pricing_combined_volume_output_2)      
        
        # Calculate CPTO and NTO (CPTO minus Taxes)
        ########################################################################################################################        
        bat_taxes = 237.9

        df_pricing_combined_volume_output_2['Volume'] = df_pricing_combined_volume_output_2['Volume'].astype('float')
        #df_pricing_combined_volume_output_2['PACK_PRICE'] = df_pricing_combined_volume_output_2['PACK_PRICE'].astype('float')

        df_pricing_combined_volume_output_2['CPTO'] = round((df_pricing_combined_volume_output_2['Volume'] * 20),2)
        df_pricing_combined_volume_output_2['CPTO_less_Taxes'] = round((df_pricing_combined_volume_output_2['CPTO'] - bat_taxes),2)
                    
        return df_pricing_combined_volume_output_1, df_pricing_combined_volume_output_2
######################################################################################################


def correct_price_elasticity(df_pricing_combined_all):
    delta_change = pd.DataFrame()
    delta_change['price_segment'] = df_pricing_combined_all[df_pricing_combined_all['Price_Type'] == 'Old Price']['PRICE_CLASS']
    delta_change['price_old'] = df_pricing_combined_all[df_pricing_combined_all['Price_Type'] == 'Old Price']['AVG_PRICE_20']
    delta_change['price_new'] = df_pricing_combined_all[df_pricing_combined_all['Price_Type'] == 'New Price']['AVG_PRICE_20']

    delta_change['volume_old'] = df_pricing_combined_all[df_pricing_combined_all['Price_Type'] == 'Old Price']['Volume']
    delta_change['volume_new'] = df_pricing_combined_all[df_pricing_combined_all['Price_Type'] == 'New Price']['Volume']
    
    delta_change['DELTA_PRICE'] = delta_change['price_new'].astype('float') - delta_change['price_old']
    delta_change['DELTA_VOLUME'] = delta_change['volume_new'] - delta_change['volume_old']
 
    
    for i in range(len(delta_change['price_old'])):   
        elasticity_factor = 1                     

        # Check if both the price and volume move in same directions (both positive/both negative). This is an example of positive elasticity 
        # and needs to be handled as below
        if (((delta_change.loc[i, 'DELTA_PRICE'] > 0) & (delta_change.loc[i, 'DELTA_VOLUME'] > 0)) or 
             ((delta_change.loc[i, 'DELTA_PRICE'] < 0) & (delta_change.loc[i, 'DELTA_VOLUME'] < 0))):
             
             # Calculate the elasticity factor based on different price class .. 
             if delta_change.loc[i, 'price_segment'] == 'ASPRM':
                 elasticity_factor = -1.85460227649788
             elif delta_change.loc[i, 'price_segment'] == 'DNP':    
                 elasticity_factor = -1.43358363366705
             elif delta_change.loc[i, 'price_segment'] == 'LOW':    
                 elasticity_factor = -1.66378993979861
             elif delta_change.loc[i, 'price_segment'] == 'PREMIUM':    
                 elasticity_factor = -1.44220911051768
             elif delta_change.loc[i, 'price_segment'] == 'Premium':    
                 elasticity_factor = -1.24408244891175        
             elif delta_change.loc[i, 'price_segment'] == 'VFM':    
                 elasticity_factor = -1.12611768289494        
             
             #delta_change.loc[i, 'NEW_DELTA_VOLUME'] = (elasticity_factor.abs()) * ((delta_change.loc[i, 'DELTA_PRICE'].abs())/delta_change.loc[i, 'price_old']) * delta_change.loc[i, 'volume_old']
             delta_change.loc[i, 'NEW_DELTA_VOLUME'] = elasticity_factor * (delta_change.loc[i, 'DELTA_PRICE']/delta_change.loc[i, 'price_old']) * delta_change.loc[i, 'volume_old']

             delta_change['NEW_VOLUME'] = np.where((delta_change['DELTA_PRICE'] < 0), delta_change['volume_old'] + delta_change['NEW_DELTA_VOLUME'], 
                                          np.where((delta_change['DELTA_PRICE'] > 0), delta_change['volume_old'] - delta_change['NEW_DELTA_VOLUME'], 
                                          delta_change['volume_old']))

             return round(delta_change['NEW_VOLUME'], 2)
        else:
            return round(delta_change['volume_new'], 2)
##################################################################################################################################        


def brand_mobility(df_predicted): ## Fetch the Competitors details to calculate the brand mobility from Snowflake ..   

    df_competitor_data_all = pd.DataFrame()
    for i in range(len(df_predicted)):        
        state = df_predicted.loc[i, 'STATE']
        #player = df_predicted.loc[i, 'PLAYER']
        segment = df_predicted.loc[i, 'SEGMENT']
        #family = df_predicted.loc[i, 'FAMILY']
        price_class = df_predicted.loc[i, 'PRICE_CLASS']
        
        fetch_query = f'select * from "BRA_DEV_INTEGRATION"."PRI_SIM"."SV_RGM_VOLUME_SHARE"  where STATE = \'{state}\' and SEGMENT = \'{segment}\' and PRICE_CLASS = \'{price_class}\'  and COMPETITOR_VOLUME_SHARE != {0}'   
        df_competitor_data = data_load_snowflake(login_user='RGM_BRA_DEV_SERVICE_USER', login_password='9MZeZKa8DktKrHKj', login_account='fx54096.west-europe.azure', data_warehouse='BRA_DEV_PRESENTATION_ADHOC_WH', data_query = fetch_query)    
        
        df_competitor_data.drop(['SOURCE_SYSTEM', 'INSERT_TS'], axis = 1, inplace=True)    

        # Negating the value -- as the delat volume share loss/profit is moving into competitor's share
        df_competitor_data['COMP_VOL_SHARE_ABS'] = -round(df_competitor_data['COMPETITOR_VOLUME_SHARE'].apply(lambda x: x * df_predicted.loc[i, 'delta_volume']), 2)
        
        df_competitor_data['delta_volume'] = df_predicted.loc[i, 'delta_volume']
        df_competitor_data_all = pd.concat([df_competitor_data_all, df_competitor_data], ignore_index=True)

    if sum(df_competitor_data_all['COMP_VOL_SHARE_ABS']) == 0: # For no change in absolute share value, percentage change is not calculated
        df_competitor_data_all['COMP_VOL_SHARE_PER'] = 0
    else:
        df_competitor_data_all['COMP_VOL_SHARE_PER'] = round(df_competitor_data_all['COMP_VOL_SHARE_ABS'].apply(lambda x: (x / sum(df_competitor_data_all['COMP_VOL_SHARE_ABS'])*100)), 2)
    #df_competitor_data_all['COMP_VOL_SHARE_PER'] = round(df_competitor_data_all['COMP_VOL_SHARE_ABS'].apply(lambda x: (x / sum(df_competitor_data_all['COMP_VOL_SHARE_ABS'])*100)), 2)
    return df_competitor_data_all        
##################################################################################################################################        
