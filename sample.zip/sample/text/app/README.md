# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Quick summary:
This is a dash application intended to cater around multiple markets and provide great insights on predicting pricing trend for Canada market. This would help the end user to fix pricing for certain products based on region of introduction and also to analyze previous pricing trends.

* Version:
1.0.1

### How do I get set up? ###

* Summary of set up:
- git clone https://batdigital.visualstudio.com/OneDRA/_git/DataScienceSolutions (Clone the repository)
- cd hub\solutions\marketing\pricing_solutions\canada\intelli_price (Change to relevant application directory)
- python3 -m venv canadaPricingVenv (Create virtual environment from existing python3)
- activate the "canadaPricingVenv" (Activating the virtual environment)
- pip install -r requirements\base.txt (Install all required python modules)
- python index.py / python index.py development / python index.py testing (production / development / testing instance)

* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
- Manash J Konwar (manash_konwar@bat.com)

* Other community or team contact