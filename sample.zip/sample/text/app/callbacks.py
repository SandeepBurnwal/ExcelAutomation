__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import io
import ast
import time
import urllib
import base64
import logging
import numpy as np
import pandas as pd
import pandas as pd
import plotly.express as px

import requests
import json
import dash
import plotly.graph_objs as go
from app import app
from celery.result import AsyncResult
from config.config_all import month_int_text_mapping
from dash.dependencies import Input, Output, State
from dash_table.Format import Format, Scheme
from utility_scripts.datatable_filter import filtering_sorting_datatable
from layouts import layout_pricing_input, layout_pricing_sales, layout_kpi
from backend import brand_mobility, prepare_price_output_data, test_post_headers_body_json, prepare_price_data_model, df_snow_data

from utility_scripts.utility_data_transformation import custom_datepicker

PRICING_INPUT_DF = None # Global Variables for Pricing Input page
logger = logging.getLogger('pricing_handler') # Retrieve Logger Handler
    
#region General Callbacks
@app.callback(Output(component_id='tabs-content', component_property='children'),
            Input(component_id='tabs', component_property='value'))
def render_content(tab):
    if tab == 'tab-1':
        return layout_pricing_input.layout
    elif tab == 'tab-2':
        return layout_pricing_sales.layout
    elif tab == 'tab-3':
        return layout_kpi.layout


@app.callback(Output(component_id='bat-logo', component_property='src'),
            [Input(component_id='tabs', component_property='value')])
def render_logo(tab):
    return app.get_asset_url('BAT_New_Logo_White.png')
#endregion

##

###########################################################################################
#############################           START                ##############################
##################################  CHAINED CALL-BACKS ####################################
#############################                                ##############################
###########################################################################################

###### 1 - MARKET + Product FILTER ==> [State, Player] (Input) | Segment (Output)  ########

@app.callback([Output('dd-price-segment', 'options'), Output('dd-price-segment', 'value')],
              [Input('dd-state', 'value'), Input('dd-player', 'value')])
def update_sidepanel_segment_options(br_state, br_player):
    
    df_snow_data_filter = df_snow_data.copy()    
    
	# For the first input from Callback with one entry, convert type from str to list for all variables     
    br_state = br_state if isinstance(br_state, list) else [br_state]
    br_player = br_player if isinstance(br_player, list) else [br_player]    
        
    if len(br_state) != 0 and len(br_player) != 0:                                   
        df_snow_data_filter = df_snow_data_filter[df_snow_data_filter['STATE'].isin((br_state))]
        df_snow_data_filter = df_snow_data_filter.loc[df_snow_data_filter['PLAYER'].isin((br_player)), :]    		
                            
        segment_list = df_snow_data_filter['SEGMENT'].unique().tolist() # Extract the final segment list
        if len(segment_list) == 0:
            segment_list = ['None']
            
        return [{'label': i, 'value': i} for i in segment_list], [segment_list[0]]        
    else:
        return dash.no_update, dash.no_update
#############################################################################################


###### 2 - MARKET + Product FILTER ==> [State, Player, Segment] (Input) | Family (Output)  ########
@app.callback([Output('dd-family', 'options'), Output('dd-family', 'value')],
              [Input('dd-state', 'value'), Input('dd-player', 'value'), Input('dd-price-segment', 'value')])
def update_sidepanel_family_options(br_state, br_player, br_price_segment):
    df_snow_data_filter = df_snow_data.copy()    
    
	# For the first input from Callback with one entry, convert type from str to list for all variables     
    br_state = br_state if isinstance(br_state, list) else [br_state]
    br_player = br_player if isinstance(br_player, list) else [br_player]   
    br_price_segment = br_price_segment if isinstance(br_price_segment, list) else [br_price_segment]
        
    if len(br_state) != 0 and len(br_player) != 0 and len(br_price_segment) != 0:                                   
        df_snow_data_filter = df_snow_data_filter[df_snow_data_filter['STATE'].isin((br_state))]
        df_snow_data_filter = df_snow_data_filter.loc[df_snow_data_filter['PLAYER'].isin((br_player)), :]  
        df_snow_data_filter = df_snow_data_filter.loc[df_snow_data_filter['SEGMENT'].isin((br_price_segment)), :]                		
                            
        family_list = df_snow_data_filter['FAMILY'].unique().tolist() # Extract the final segment list
        if len(family_list) == 0:
            family_list = ['None']
            
        return [{'label': i, 'value': i} for i in family_list], [family_list[0]]        
    else:
        return dash.no_update, dash.no_update
#####################################################################################################################



###### 3 - MARKET + Product FILTER ==> [State, Player, Segment, Family] (Input) | Price_Class (Output)  ########
#####################################################################################################################
@app.callback([Output('dd-price-class', 'options'), Output('dd-price-class', 'value')],
              [Input('dd-state', 'value'), Input('dd-player', 'value'), Input('dd-price-segment', 'value'), Input('dd-family', 'value')])
def update_sidepanel_price_class_options(br_state, br_player, br_price_segment, br_family):
    
    df_snow_data_filter = df_snow_data.copy()    
    
	# For the first input from Callback with one entry, convert type from str to list for all variables     
    br_state = br_state if isinstance(br_state, list) else [br_state]
    br_player = br_player if isinstance(br_player, list) else [br_player]   
    br_price_segment = br_price_segment if isinstance(br_price_segment, list) else [br_price_segment]
    br_family = br_family if isinstance(br_family, list) else [br_family]
        
    if len(br_state) != 0 and len(br_player) != 0 and len(br_price_segment) != 0 and len(br_family) != 0:                                   
        df_snow_data_filter = df_snow_data_filter[df_snow_data_filter['STATE'].isin((br_state))]
        df_snow_data_filter = df_snow_data_filter.loc[df_snow_data_filter['PLAYER'].isin((br_player)), :]
        df_snow_data_filter = df_snow_data_filter.loc[df_snow_data_filter['SEGMENT'].isin((br_price_segment)), :]        
        df_snow_data_filter = df_snow_data_filter.loc[df_snow_data_filter['FAMILY'].isin((br_family)), :]        
                            
        price_class_list = df_snow_data_filter['PRICE_CLASS'].unique().tolist() # Extract the final segment list
        if len(price_class_list) == 0:
            price_class_list = ['None']
            
        return [{'label': i, 'value': i} for i in price_class_list], [price_class_list[0]]        
    else:
        return dash.no_update, dash.no_update
#############################################################################################
#############################################################################################
###########################################################################################
#############################             END                ##############################
##################################  CHAINED CALL-BACKS ####################################
#############################                                ##############################
###########################################################################################


### BRAZIL -- Price Input Data-table
@app.callback([Output('datatable-price', 'data'),
              Output('datatable-price', 'columns'),
              Output('intermediate-value', 'data')], # dcc.Store
            [Input('dd-state', 'value'),
            Input('dd-player', 'value'),
            Input('dd-price-segment', 'value'),
            Input('dd-family', 'value'),
            Input('dd-price-class', 'value'),
            Input('upload-data', 'contents')],
            State('storage-pricing-input', 'data'), State('intermediate-value', 'data'))
def simulation_input_data(br_state, br_player, br_price_segment, br_family, br_price_class, uploaded_content, stored_pricing_input, stored_pricing_input_2):
    global PRICING_INPUT_DF

    # Identification of Triggering Point
    ctx = dash.callback_context
    if not ctx.triggered:
        trigger_component_id = 'No clicks yet'  
    else:
        trigger_component_id = ctx.triggered[0]['prop_id'].split('.')[0]
    
    # Check for stored pricing input
    '''
    if stored_pricing_input_2 is not None and trigger_component_id != 'btn-reset-simulator':
        df_templatedata = pd.DataFrame(stored_pricing_input_2)
        #column_name = ['KEYACCOUNT', 'REGION', 'BANNER', 'MANUFACTURER', 'PRICE_SEGMENT', 'BRAND', 'SUB_BRAND', 'PRODUCT', 'PACK_SIZE']
        #df_templatedata = df_templatedata[column_name]

        return df_templatedata.to_dict("records")
    '''

    # If upload input is selected
    if uploaded_content is not None:
        decoded = base64.b64decode(uploaded_content.split(",")[1])
        df_templatedata = pd.read_csv(io.StringIO(decoded.decode('utf-8')))        
        #column_name = ['KEYACCOUNT', 'REGION', 'BANNER', 'MANUFACTURER', 'PRICE_SEGMENT', 'BRAND', 'SUB_BRAND', 'PRODUCT', 'PACK_SIZE']
        #df_templatedata = df_templatedata[column_name]
        return df_templatedata.to_dict("records"), dash.no_update, dash.no_update   

    # For the first input from Callback with one entry, convert type from str to list for all variables     
    br_state = br_state if isinstance(br_state, list) else [br_state]
    br_player = br_player if isinstance(br_player, list) else [br_player]    
    br_family = br_family if isinstance(br_family, list) else [br_family]
    br_price_class = br_price_class if isinstance(br_price_class, list) else [br_price_class]
    br_price_segment = br_price_segment if isinstance(br_price_segment, list) else [br_price_segment]

    # For all features, after list conversion data is filtered if the list is not empty
    df_snow_data_new = df_snow_data.copy() 
    #df_snow_data_new = df_snow_data_new[df_snow_data_new['AVG_PRICE_20'].notnull()]
    df_snow_data_new.dropna(inplace=True)

    if len(br_state) != 0:
        df_snow_data_new = df_snow_data_new[df_snow_data_new['STATE'].isin((br_state))]
    if len(br_player) != 0:
        df_snow_data_new = df_snow_data_new.loc[df_snow_data_new['PLAYER'].isin((br_player)), :]            
    if len(br_price_segment) != 0:
        df_snow_data_new = df_snow_data_new.loc[df_snow_data_new['SEGMENT'].isin((br_price_segment)), :]        
    if len(br_family) != 0:
        df_snow_data_new = df_snow_data_new.loc[df_snow_data_new['FAMILY'].isin((br_family)), :]        
    if len(br_price_class) != 0:
        df_snow_data_new = df_snow_data_new.loc[df_snow_data_new['PRICE_CLASS'].isin((br_price_class)), :]        
    ###################              

    # Mapping the month from number to text and ordering them      
    df_snow_data_new['MONTH'] = df_snow_data_new['MONTH'].map(month_int_text_mapping)
    df_snow_data_new['AVG_PRICE_20'] = round(df_snow_data_new['AVG_PRICE_20'], 2)
    df_snow_data_new['Period'] = df_snow_data_new['YEAR'].astype(str) +'_'+ df_snow_data_new['MONTH'].astype(str)
    
    df_snow_data_new = df_snow_data_new.pivot_table('AVG_PRICE_20', ['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS', 'SALES'], 'Period')
    #df_snow_data_new = df_snow_data_new.pivot_table('AVG_PRICE_20', ['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS'], 'Period')
    df_snow_data_new = pd.DataFrame(df_snow_data_new.to_records())  # Convert the Pivot table into the dataframe 

    # Getting rid of numerical part from the column names
    all_cols_new = [ele for ele in df_snow_data_new.columns if ele not in ['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS', 'SALES']]
    #all_cols_new = [ele for ele in df_snow_data_new.columns if ele not in ['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS']]
    for col in all_cols_new:
        df_snow_data_new.rename(columns={col: col[0:5] + col[-3:]}, inplace=True)    
    ###################    
    
# Updating Global Pricing Input Variable
    if PRICING_INPUT_DF is not None:
        PRICING_INPUT_DF = None
    PRICING_INPUT_DF = df_snow_data_new

    column_dynamic_list = []
    
    #df_snow_data_new = df_snow_data_all
    column_list = ['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS']
    for column_name in df_snow_data_new.columns:
        if column_name in column_list:
            column_dynamic_list.append({"name": column_name, "id": column_name, 'editable': False})
        else:
            column_dynamic_list.append({"name": column_name, "id": column_name, 'editable': True})
        
    # Filtering & Sorting Part of Table
    #df_snow_data_new2 = filtering_sorting_datatable(df_snow_data_new, filter, sort_by, page_current, page_size)

    # Return the pricing input datatble, list of columns and the dataframe(price) as a Div element to be used in another callback
    return df_snow_data_new.to_dict('records'), column_dynamic_list, df_snow_data_new.to_json(date_format='iso', orient='split')
#########################################################################################################################


# Download template link
@app.callback(Output(component_id='template-btn-anchor', component_property='href'),
            [Input(component_id='btn-template', component_property='n_clicks'),
            State(component_id='datatable-price', component_property='data')])
def download_template_link(on_click, tbdata):
    if on_click is not None and len(tbdata)>0:
        oritemplate = pd.DataFrame(data = tbdata)
        extemplate = oritemplate.to_csv(index = False, encoding = "utf-8")
        extemplate = "data:text/csv;charset=utf-8,%EF%BB%BF" + urllib.parse.quote(extemplate)
        return extemplate
#endregion
########################################################################################################################         


#region Running Simulations
@app.callback([Output('storage-pricing-output', 'data'), Output('storage-pricing-output_all', 'data'),
               Output('storage-pricing-output_display', 'data'), Output('storage-pricing-output_all_display', 'data'),
               Output('storage-pricing-input', 'data')],
              [Input('btn-run-simulation', 'n_clicks'), Input('intermediate-value', 'data')],
              [State('datatable-price', 'data'),
              State('storage-pricing-output', 'data'),
              State('storage-pricing-input', 'data')], prevent_initial_call=True)
def run_prediction(n_run_simulation, df_pricing_old, pricing_input, pricing_output_state, pricing_input_state):

    # Identification of Triggering Point
    ctx = dash.callback_context
    if not ctx.triggered:
        trigger_component_id = 'No clicks yet'  
    else:
        trigger_component_id = ctx.triggered[0]['prop_id'].split('.')[0]

    # Conditional Output wrt Input Source Type
    if trigger_component_id == 'btn-run-simulation' and n_run_simulation:
        print('Run Simulation Clicked')

        ''' 
        Step 0 > Drop 'Unnamed: 0' from Snowflake (dcc.Store) original dataframe with all columns
        Step 1 > Create the new price dataframe from callback with user prices | Create the old price dataframe from dcc.Store (Snowflake) 
        Step 1.1 > Call function - 'prepare_price_data_model' to perform below steps for both new and old pricing data required for model trigger
                 Step 2 > Convert the year_month price column into a single column (Values) with all price data using melt function
                 Step 3 > Using the price and pack size information from dataframe created in Step 1, update the PRICE_PER_STICK in original dataframe
                 Step 4 > Drop the 'Unnamed: 0' col from original dataframe
                 Step 5 > Drop 'Price_per_pack', 'Value' from both New + Old price dataframe created in Step 1
                 Step 6 > Merge New + Old dataframe with Original so as to take reamaining 30+ features required for trigerring the model
                 Step 7 > Encoding the categorical features 
        '''
              
        # START OF Input Data Loop. FOr from sets of input (old + new) data, extract once set, process it and combine with all at the end 
        df_pricing_input = pd.DataFrame(data=pricing_input)            # Extracting input pricing table data where price is updated by the end user
        df_pricing_old = pd.read_json(df_pricing_old, orient='split')  # Existing data from snowflake with old prices
        
        df_pricing_old.drop(columns=['SALES'], axis=1, inplace=True) # Drop SALES COl from above 2 dataframe
        df_pricing_input.drop(columns=['SALES'], axis=1, inplace=True) # Drop SALES COl from above 2 dataframe

        # ONE Set of Data (OLD Price + NEW Price) --> Encoding the data as required for the model end-point prediction
        df_pricing_old_encoded = prepare_price_data_model(df_pricing_old)
        df_pricing_input_encoded = prepare_price_data_model(df_pricing_input)
        
        # ONE Set of Data (OLD Price + NEW Price) --> Prediction the Rest api - model end-point
        pred_test_old = test_post_headers_body_json(df_pricing_old_encoded)
        pred_test_new = test_post_headers_body_json(df_pricing_input_encoded)        
        df_pricing_combined_volume_output_1, df_pricing_combined_volume_output_2 = prepare_price_output_data(df_pricing_input, pred_test_new, df_pricing_old, pred_test_old)                     
        
        # END OF Input Data Loop 
########################################################################              

        # Below 2 sets of sales volume output dataframe is prepared and returned. One for display pupose with comma and the other without comma for calculation purpose in the KPI tab
        df_pricing_combined_volume_output_1_display = df_pricing_combined_volume_output_1.copy()
        df_pricing_combined_volume_output_2_display = df_pricing_combined_volume_output_2.copy()

        #### Adding comma for display ##########
        # For display purpose with commas. For each value of volume predicted from the model, below loop adds a comma to the sales volume 
        for col in df_pricing_combined_volume_output_1_display.columns:
            if col not in ['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS', 'Price_Type']:
                df_pricing_combined_volume_output_1_display[col] = df_pricing_combined_volume_output_1_display.apply(lambda x: "{:,.0f}".format(x[col]), axis=1)        
            
        # For each value of volume predicted from the model, below loop adds a comma to the below 3 columns 
        for col in ['Volume', 'CPTO', 'CPTO_less_Taxes']:
            df_pricing_combined_volume_output_2_display[col] = df_pricing_combined_volume_output_2_display.apply(lambda x: "{:,.0f}".format(x[col]), axis=1)        
        
        #### END of Adding comma for display ##########

        return df_pricing_combined_volume_output_1.to_dict('records'), df_pricing_combined_volume_output_2.to_dict('records'), df_pricing_combined_volume_output_1_display.to_dict('records'), df_pricing_combined_volume_output_2_display.to_dict('records'), df_pricing_input.to_dict('records')

    elif trigger_component_id == 'datatable-price':
        if pricing_input_state is None and pricing_output_state is None:
            return pd.DataFrame().to_dict('records'), pd.DataFrame().to_dict('records'), pd.DataFrame().to_dict('records'), pd.DataFrame().to_dict('records'), pd.DataFrame().to_dict('records')
        elif df_pricing_old is not None and pricing_output_state is not None:
            return pricing_output_state, pricing_output_state, pricing_output_state, pricing_output_state, df_pricing_old
    else:
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update                
##########################################################################################################################


# Device Sales Datatable Population
@app.callback([#Output('sbc-sales', 'figure'),
               Output('datatable-output', 'data'), Output('datatable-output', 'columns')],
               #Output('datatable-output_all', 'data'), Output('datatable-output_all', 'columns')],
            #[Input('storage-pricing-output_display', 'data'), Input('storage-pricing-output_all_display', 'data'), Input('dd-plot-type', 'value')])
            [Input('storage-pricing-output_display', 'data'), Input('storage-pricing-output_all_display', 'data')])
            
#def sales_output(stored_sales_prediction, stored_sales_prediction_all, plot_type):
def sales_output(stored_sales_prediction, stored_sales_prediction_all):
    if stored_sales_prediction is not None:
        df_predicted = pd.DataFrame(stored_sales_prediction)

    if stored_sales_prediction_all is not None:        
        df_predicted_all = pd.DataFrame(stored_sales_prediction_all)
        print('predict volume --- ', df_predicted)
    
        # Modifying Predicted Data to fulfil the representation type 
        '''
        if prediction_value_type.__eq__('Sticks'):
            pass
        elif prediction_value_type.__eq__('Share'):
            df_intermediate = df_predicted.copy()
            # Converting string based predicted values to float column type
            # Divinding each column value by sum of the column
            for colname in df_intermediate.columns[3:]:
                try:
                    df_intermediate[colname] = df_intermediate[colname].astype(float)
                    df_intermediate[colname] = (df_intermediate[colname]/df_intermediate[colname].sum()) * 100
                except Exception:
                    continue
            # Round off intermediate dataframe
            df_intermediate = df_intermediate.round(4)
            # Assign df_predicted 
            df_predicted = df_intermediate
        elif prediction_value_type.__eq__('Value'):
            pass
        '''
        column_list = []
        for column_name in df_predicted.columns:
            column_list.append({"name": column_name, "id": column_name})

        column_list_all = []
        for column_name in df_predicted_all.columns:
            column_list_all.append({"name": column_name, "id": column_name}) 


        '''
        # Ploting here
        ######################################               
        if plot_type == 'Volume':
            fig = px.scatter(df_predicted_all, x=df_predicted_all['Period'], y=df_predicted_all['Volume'], hover_data=['Period', 'Volume'], facet_col='Price_Type', color='Price_Type')       # text='Group',                          
            #fig = px.line(df_predicted_all, x=df_predicted_all['Period'], y=df_predicted_all['Volume'], hover_data=['Period', 'PACK_PRICE', 'Volume'], color='Price_Type')       # text='Group',                                                  
            fig.update_traces(marker_size=12, marker_line=dict(width=2))
        else:
            #fig = px.scatter(df_predicted_all, x=df_predicted_all['Period'], y=df_predicted_all['CPTO'], hover_data=['Period', 'PACK_PRICE', 'CPTO', 'CPTO_less_Taxes'], facet_col='Price_Type', color='Volume_changed')            
            fig = px.line(df_predicted_all, x=df_predicted_all['Period'], y=df_predicted_all['CPTO'], hover_data=['Period', 'CPTO', 'CPTO_less_Taxes'], color='Price_Type')            
            fig.update_traces(marker_size=12, marker_line=dict(width=2))
        '''

        #return fig, df_predicted.to_dict('records'), column_list, df_predicted_all.to_dict('records'), column_list_all
        #return fig, df_predicted.to_dict('records'), column_list
        return df_predicted.to_dict('records'), column_list
    else:
        return dash.no_update, dash.no_update
#################################################################################################



# Data preparation for the KPI Tab 
#################################################################################################
@app.callback([Output('delta_volume_abs', 'children'), Output('delta_volume_per', 'children'), Output('delta_volume_abs', 'style'), Output('delta_volume_per', 'style'),
               Output('cpto_nto_abs', 'children'), Output('cpto_nto_per', 'children'), Output('cpto_nto_abs', 'style'), Output('cpto_nto_per', 'style'),
               Output('price_delta_abs', 'children'), Output('price_delta_per', 'children'), Output('price_delta_abs', 'style'), Output('price_delta_per', 'style'),
               #Output('competitor-share', 'figure'), 
               Output('competitor-group-share', 'figure'),               
               #Output('datatable-kpi', 'data'), Output('datatable-kpi', 'columns'),
               Output('datatable-competitor', 'data'), Output('datatable-competitor', 'columns')], 
               [Input('dd-group-one', 'value'), Input('dd-state_filter', 'value'), Input('data_view', 'value'), 
                Input('storage-pricing-output', 'data'), Input('storage-pricing-output_all', 'data')])
            
def kpi_output(group_one, state_filter, data_view, stored_sales_prediction, stored_sales_prediction_all):
    if stored_sales_prediction is not None:
        df_predicted = pd.DataFrame(stored_sales_prediction)
        #df_predicted.drop(['Sticks_in_pack'], axis = 1, inplace=True)
        df_predicted['volume_sum'] = round(df_predicted.sum(numeric_only = True, axis=1), 2) # Sum of all volume predictions - OLD, NEW  

        df_predicted = df_predicted.pivot_table('volume_sum', ['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS'], 'Price_Type')                
        df_predicted = pd.DataFrame(df_predicted.to_records())  # Convert the Pivot table into the dataframe 
        
        df_predicted.rename(columns={'New Price': 'Total New Vol', 'Old Price': 'Total Old Vol'}, inplace=True)
        df_predicted['delta_volume'] = round(df_predicted['Total New Vol'] - df_predicted['Total Old Vol'], 2)       

        # Handle the brand mobility here !!  
        df_competitor_data = brand_mobility(df_predicted)
        df_competitor_data = df_competitor_data.sort_values(by=['delta_volume'], ascending=False)

        ### Grouped Data ###
        if data_view == 'Percentage':
            data_view_col = 'COMP_VOL_SHARE_PER'
        else:
            data_view_col = 'COMP_VOL_SHARE_ABS'

        if state_filter != 'All':
            df_competitor_data = df_competitor_data[df_competitor_data['STATE'] == state_filter]

        df_competitor_grouped = round(df_competitor_data.groupby(group_one, as_index = False)[data_view_col].sum(), 2)
        df_competitor_grouped = pd.DataFrame(df_competitor_grouped.to_records())  # Convert the Pivot table into the dataframe 
        df_competitor_grouped = df_competitor_grouped.sort_values(by=[data_view_col], ascending=False)

        share_fig = go.Figure(data=[go.Bar(x=df_competitor_grouped[group_one], y=df_competitor_grouped[data_view_col], text=df_competitor_grouped[data_view_col], textposition='auto')])
        share_fig.update_layout(title_text=f"Competitor Share - Grouped by {group_one.title()} ", barmode="stack", uniformtext=dict(mode="hide", minsize=10))                
        ################################
 
        column_list_comp = []
        for column_name in df_competitor_data.columns:
            column_list_comp.append({"name": column_name, "id": column_name})
        
        '''
        fig = go.Figure()
        fig.add_trace(go.Bar(x=df_competitor_data['COMPETITOR_PRICE_CLASS'], y=df_competitor_data['COMP_VOL_SHARE_PER'], name='Competitor share by percentage', marker_color='indianred'))
        fig.add_trace(go.Bar(x=df_competitor_data['COMPETITOR_PRICE_CLASS'], y=df_competitor_data['COMP_VOL_SHARE_ABS'], name='Competitor share by value', marker_color='lightsalmon'))
        fig.update_layout(barmode='group', xaxis_tickangle=-45)  # Here we modify the tickangle of the xaxis, resulting in rotated labels.
        '''

        # FIRST KPI TAB OUTPUT - Volume Delta
        delta_vol_abs = round(df_predicted['delta_volume'].sum(), 4)
        delta_vol_per = round((delta_vol_abs / df_predicted['Total Old Vol'].sum()) * 100, 4)

        if delta_vol_abs < 0:
            delta_volume_style = {'color':'red', 'font-size':'110%'}
        else:
            delta_volume_style = {'color':'green', 'font-size':'110%'}    
        ################################

        # SECOND KPI TAB OUTPUT - CPTO/NTO delta      
        stored_sales_prediction_all = pd.DataFrame(stored_sales_prediction_all)
        stored_sales_prediction_all_old = stored_sales_prediction_all[stored_sales_prediction_all['Price_Type'] == 'Old Price']
        stored_sales_prediction_all_new = stored_sales_prediction_all[stored_sales_prediction_all['Price_Type'] == 'New Price']
        
        delta_cpto_abs = round(stored_sales_prediction_all_new['CPTO'].astype('float').sum() - stored_sales_prediction_all_old['CPTO'].astype('float').sum(), 4)
        delta_cpto_per = round(delta_cpto_abs/stored_sales_prediction_all_old['CPTO'].astype('float').sum() * 100, 4)
        
        if delta_cpto_abs < 0:
            delta_cpto_style = {'color':'red', 'font-size':'110%'}
        else:
            delta_cpto_style = {'color':'green', 'font-size':'110%'}          
        ################################

        # THIRD KPI TAB OUTPUT - PRICE delta      
        delta_price_abs = round(stored_sales_prediction_all_new['AVG_PRICE_20'].astype('float').sum() - stored_sales_prediction_all_old['AVG_PRICE_20'].astype('float').sum(), 4)
        delta_price_per = round(delta_price_abs/stored_sales_prediction_all_old['AVG_PRICE_20'].astype('float').sum() * 100, 4)
        
        if delta_price_abs < 0:
            delta_price_style = {'color':'red', 'font-size':'110%'}
        else:
            delta_price_style = {'color':'green', 'font-size':'110%'} #'font-weight': 'bold'   
        ################################
       
        #return f'{delta_vol_abs}R$', f'{delta_vol_per}%', delta_volume_style, delta_volume_style, f'{delta_cpto_abs}R$', f'{delta_cpto_per}%', delta_cpto_style, delta_cpto_style, f'{delta_price_abs}R$', f'{delta_price_per}%', delta_price_style, delta_price_style, fig, share_fig, df_competitor_data.to_dict('records'), column_list_comp
        return f'{delta_vol_abs}R$', f'{delta_vol_per}%', delta_volume_style, delta_volume_style, f'{delta_cpto_abs}R$', f'{delta_cpto_per}%', delta_cpto_style, delta_cpto_style, f'{delta_price_abs}R$', f'{delta_price_per}%', delta_price_style, delta_price_style, share_fig, df_competitor_data.to_dict('records'), column_list_comp
    else:
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update
#################################################################################################
#################################################################################################


# Download Device Sales link
@app.callback(Output('sales-btn-anchor', 'href'),
            Input('btn-download-sales', 'n_clicks'),
            State('datatable-output', 'data'), State('datatable-output_all', 'data'))
def sales_download_link(on_click, sales_data, sales_data_all):

    # Identification of Triggering Point
    ctx = dash.callback_context
    if not ctx.triggered:
        trigger_component_id = 'No clicks yet'  
    else:
        trigger_component_id = ctx.triggered[0]['prop_id'].split('.')[0]

    # Conditional Output wrt Input Source Type
    if trigger_component_id == 'btn-download-sales':
        oritemplate = pd.DataFrame(data = sales_data)
        #oritemplate_all = pd.DataFrame(data = sales_data_all)
        #oritemplate = pd.concat(oritemplate, oritemplate_all)

        extemplate = oritemplate.to_csv(index = False, encoding = "utf-8")
        extemplate = "data:text/csv;charset=utf-8,%EF%BB%BF" + urllib.parse.quote(extemplate)
        return extemplate
          
    #endregion
#################################################################################################

