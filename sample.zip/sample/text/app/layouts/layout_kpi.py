__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import numpy as np
import dash_table as dt
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
from backend import df_snow_data

competitor_cols = ['COMPETITOR_PLAYER', 'COMPETITOR_FAMILY', 'COMPETITOR_PRICE_CLASS']

layout = html.Div([
            # dbc.Row([
            #     dbc.Col(dt.DataTable(
            #                 id='datatable-kpi',
            #                 style_header={
            #                         'whiteSpace': 'normal',
            #                         'backgroundColor': '#172962',
            #                         'color': 'white'
            #                     },
            #                 style_table={
            #                     'height': 350,
            #                     'overflowX': 'scroll',
            #                     'overflowY': 'scroll'
            #                 },
            #                 style_cell={
            #                     'fontSize': '1.5vh',
            #                     'textAlign': 'center',
            #                     "color": "black"
            #                     },
            #                 page_current= 0,
            #                 page_size= 5
            #                 ), align="center")
            # ], 
            # style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':5, 'marginRight':10}),
            
            html.Br(),    
            html.H6('*All volume is in 1000s'),
            html.H6('*All revenue/cpto is in local currency'),     
            dbc.Row([dbc.Card([     
                                    dbc.CardHeader("Volume Delta"),
                                    dbc.CardBody(
                                        [    
                                            dbc.Row([dbc.Col(html.Div(id='delta_volume_abs')), 
                                                     dbc.Col(html.Div(id='delta_volume_per'))])                                                                                                                                    
                                        ]
                                    ),
                                ],
                                style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':20, 'marginRight':10}, color="dark", inverse=True),
                     dbc.Card([
                                    dbc.CardHeader("CPTO/NTO Delta"),
                                    dbc.CardBody(
                                        [
                                            dbc.Row([dbc.Col(html.Div(id='cpto_nto_abs')), 
                                                     dbc.Col(html.Div(id='cpto_nto_per'))])                                                                                                                                    
                                        ]
                                    ),
                                ],
                                style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':20, 'marginRight':10}, color="dark", inverse=True),           
                     dbc.Card([
                                    dbc.CardHeader("Price Delta*"),
                                    dbc.CardBody(
                                        [
                                            dbc.Row([dbc.Col(html.Div(id='price_delta_abs')), 
                                                     dbc.Col(html.Div(id='price_delta_per'))])                                                                                                                                    
                                        ]
                                    ),
                                ],
                                style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':20, 'marginRight':10}, color="dark", inverse=True),           
                     dbc.Card([
                                    dbc.CardHeader("Gross Margin*"),
                                    dbc.CardBody(
                                        [
                                            dbc.Row([dbc.Col(html.Div(id='gross_margin_abs')), 
                                                     dbc.Col(html.Div(id='gross_margin_per'))])                                                                                                                                    
                                        ]
                                    ),
                                ],
                                style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':20, 'marginRight':10}, color="dark", inverse=True),                                            
                     dbc.Card([
                                    dbc.CardHeader("Share Delta"),
                                    dbc.CardBody(
                                        [
                                            dbc.Row([dbc.Col(html.Div(id='share_delta_abs')), 
                                                     dbc.Col(html.Div(id='share_delta_per'))])                                                                                                                                    
                                        ]
                                    ),
                                ],
                                style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':20, 'marginRight':10}, color="dark", inverse=True),           
                                
                            ]),

            dbc.Row([
                dbc.Col(dt.DataTable(
                            id='datatable-competitor',
                            style_header={
                                    'whiteSpace': 'normal',
                                    'backgroundColor': '#172962',
                                    'color': 'white'
                                },
                            style_table={
                                'height': 350,
                                'overflowX': 'scroll',
                                'overflowY': 'scroll'
                            },
                            style_cell={
                                'fontSize': '1.5vh',
                                'textAlign': 'center',
                                "color": "black"
                                },
                            page_current= 0,
                            page_size= 1000
                            ), align="center")
            ], 
            style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':5, 'marginRight':10}),

            # dbc.Row([dbc.Col(dbc.Card(dcc.Graph(id='competitor-share'), body=True, color="secondary", outline=True))
            # ], style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10}),  

            dbc.Row([
                dbc.Col(dcc.Dropdown(
                                    id='dd-group-one',
                                    options=[{'label': i, 'value': i} for i in competitor_cols],
                                    value=competitor_cols[0],
                                    clearable=True,
                                    searchable=True,
                                    placeholder='Select Group 1',
                                    style={
                                        'fontSize': '2vh',
                                        'color': 'black'
                                    })),
                dbc.Col(dcc.Dropdown(
                                    id='dd-state_filter',
                                    options=[{'label': i, 'value': i} for i in np.append('All', sorted(df_snow_data['STATE'].unique().tolist()))],
                                    value='All',
                                    clearable=True,
                                    searchable=True,
                                    placeholder='Select Group 1',
                                    style={
                                        'fontSize': '2vh',
                                        'color': 'black'
                                    })),                       
                dcc.RadioItems(id='data_view',
                               options=[{'label': i, 'value': i} for i in ['Percentage', 'Absolute']],
                               value='Percentage',
                               labelStyle={'display': 'inline-block'})                                                
            ], 
            style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10}),

            dbc.Row([dbc.Col(dbc.Card(dcc.Graph(id='competitor-group-share'), body=True, color="secondary", outline=True))
            
            ], 
            style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10}),                                                
        ])



