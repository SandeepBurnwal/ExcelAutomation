__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import dash_table as dt
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc

layout = html.Div([
            dbc.Row([
                dbc.Col(html.A(dbc.Button(
                                    "Download Predicted Sales", 
                                    id='btn-download-sales', 
                                    color="info", 
                                    className="mr-1"), 
                                    id='sales-btn-anchor',
                                    href="", 
                                    download="South-Africa_Predicted_Sales.csv", 
                                    target="_blank"),
                style={'text-align':'right'})
            ], 
            style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10}),

            dbc.Row([
                dbc.Col(dt.DataTable(
                            id='datatable-output',
                            style_header={
                                    'whiteSpace': 'normal',
                                    'backgroundColor': '#172962',
                                    'color': 'white'
                                },
                            style_table={
                                'height': 350,
                                'overflowX': 'scroll',
                                'overflowY': 'scroll'
                            },
                            style_cell={
                                'fontSize': '1.5vh',
                                'textAlign': 'center',
                                "color": "black"
                                },
                            page_current= 0,
                            page_size= 1000
                            ), align="center")
            ], 
            style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':5, 'marginRight':10}),
            
            # dbc.Row([
            #     dbc.Col(dt.DataTable(
            #                 id='datatable-output_all',
            #                 style_header={
            #                         'whiteSpace': 'normal',
            #                         'backgroundColor': '#172962',
            #                         'color': 'white'
            #                     },
            #                 style_table={
            #                     'height': 350,
            #                     'overflowX': 'scroll',
            #                     'overflowY': 'scroll'
            #                 },
            #                 style_cell={
            #                     'fontSize': '1.5vh',
            #                     'textAlign': 'center',
            #                     "color": "black"
            #                     },
            #                 page_current= 0,
            #                 page_size= 1000    
            #                 ), align="center")
            # ], 
            # style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':5, 'marginRight':10}),

            ## SALES TAB - OUTPUT PLOT ## 

            # dbc.Row([
            #     dbc.Col([
            #         html.Div([
            #             # Select the Plot type - Bar/ Scatter   
            #             html.Label('Plot Type:', style={'font-weight': 'bold', 'color': '#000000'}),
            #             html.Div([
            #                 dcc.Dropdown(
            #                     id='dd-plot-type',
            #                     options=[{'label': i, 'value': i} for i in ['Volume', 'Revenue']],
            #                     value='Volume',
            #                     multi=False,
            #                     searchable=False,
            #                     clearable=False,
            #                     placeholder='Select Plot Type',
            #                     style={
            #                         'fontSize': '2vh',
            #                         'color': 'black',
            #                     }
            #                 )
            #             ])
            #         ])
            #     ]),                
            # ],
            # style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10}),

            # dbc.Row([
            #     dbc.Col(
            #         dcc.Graph(
            #             id='sbc-sales'
            #             ),
            #     )
            # ], 
            # style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10}),
            
        ])