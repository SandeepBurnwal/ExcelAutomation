__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import dash_core_components as dcc
from dash_core_components.Store import Store
import dash_html_components as html 
import dash_bootstrap_components as dbc 
from layouts import layout_pricing_input
from backend import df_snow_data, spinner
from config.config_all import tab_style, tab_selected_style

tab_height = '7vh'
layout = html.Div([
            dbc.Row([
                dbc.Col(
                    html.Div(
                        html.A(
                            html.Img(
                                id='bat-logo',
                                height='60vh'
                                )
                            ),
                        style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10, 'text-align':'center'}),
                    width=3),
                dbc.Col(
                    html.Div(
                        html.A(
                            html.H1('BRAZIL PRICING SIMULATOR', style={'text-align': 'center', 'font-weight': 'bold', 'color': '#ffffff'})
                            ),
                        style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10}),
                    width=9)
            ], style={'backgroundColor':'#0e2b63'}),

            dbc.Row([
                dbc.Col(
                    html.Div([
                        html.Details([
                            html.Summary('Market Filter', style={'font-weight': 'bold', 'color': '#ffffff'}),
                            # BR - State Filter
                            html.Label('State:', style={'color': '#ffffff'}),
                            html.Div([
                                dcc.Dropdown(
                                    id='dd-state',
                                    options=[{'label': i, 'value': i} for i in sorted(df_snow_data['STATE'].unique().tolist())],
                                    value=df_snow_data['STATE'][100],
                                    #value=['Maranhão'],                                     
                                    disabled=False,
                                    multi=True,
                                    clearable=True,
                                    searchable=True,
                                    placeholder='Select State ',
                                    style={
                                        'fontSize': '2vh',
                                        'color': 'black'
                                    }
                                )
                            ]),
                        ], style={'color': '#ffffff', 'margin-top': '2vh', 'border':'1px white solid'}),
                        html.Details([
                            html.Summary('Product Filter', style={'font-weight': 'bold', 'color': '#ffffff'}),
                            # BR Player Filter
                            html.Label('Player', style={'color': '#ffffff'}),
                            html.Div([
                                dcc.Dropdown(
                                    id='dd-player',
                                    #options=[{'label': i, 'value': i} for i in sorted(df_snow_data['PLAYER'].unique().tolist())],
                                    options=[{'label': i, 'value': i} for i in ['BAT', 'DNP', 'JTI', 'PMI']],                                   
                                    #value=df_snow_data['PLAYER'][1000],
                                    value=['BAT'],
                                    multi=True,
                                    clearable=True,
                                    searchable=True,
                                    placeholder='Select Maker',
                                    style={
                                        'fontSize': '2vh',
                                        'color': 'black'
                                    }
                                )
                            ]),
                            # BR - Segment Filter
                            html.Label('Segment:', style={'color': '#ffffff'}),
                            html.Div([
                                dcc.Dropdown(
                                    id='dd-price-segment',
                                    options=[{'label': i, 'value': i} for i in sorted(df_snow_data['SEGMENT'].unique().tolist())],
                                    value=df_snow_data['SEGMENT'][100],
                                    #value=['ASPRM'],
                                    multi=True,
                                    clearable=True,
                                    searchable=True,
                                    placeholder='Select Segment',
                                    style={
                                        'fontSize': '2vh',
                                        'color': 'black'
                                    }
                                )
                            ]),
                            # BR - Family Filter
                            html.Label('Family:', style={'color': '#ffffff'}),
                            html.Div([
                                dcc.Dropdown(
                                    id='dd-family',
                                    options=[{'label': i, 'value': i} for i in sorted(df_snow_data['FAMILY'].unique().tolist())],
                                    value=df_snow_data['FAMILY'][100],
                                    multi=True,
                                    clearable=True,
                                    searchable=True,
                                    placeholder='Select Family',
                                    style={
                                        'fontSize': '2vh',
                                        'color': 'black'
                                    }
                                )
                            ]),
                            # BR - PRICE_CLASS Filter
                            html.Label('Price-class:', style={'color': '#ffffff'}),
                            html.Div([
                                dcc.Dropdown(
                                    id='dd-price-class',
                                    options=[{'label': i, 'value': i} for i in sorted(df_snow_data['PRICE_CLASS'].unique().tolist())],
                                    value=df_snow_data['PRICE_CLASS'][100],
                                    #value=['Free SC'],
                                    multi=True,
                                    clearable=True,
                                    searchable=True,
                                    placeholder='Select Maker',
                                    style={
                                        'fontSize': '2vh',
                                        'color': 'black'
                                    }
                                )
                            ])                            
                        ], style={'color': '#ffffff', 'margin-top': '2vh', 'border':'1px white solid'}),
                        html.Br(),
                        # Run Simulation
                        html.Div([
                            html.A(
                                dbc.Button("Run Simulation", 
                                        id='btn-run-simulation', 
                                        color="info", 
                                        block=True,
                                        className="mr-1"), 
                            id='btn-run-anchor')
                        ]),
                        html.Br(),
                        # Reset Pricing
                        html.Div([
                            html.A(
                                dbc.Button("Reset Simulator", 
                                        id='btn-reset-simulator', 
                                        color="info", 
                                        block=True,
                                        className="mr-1"), 
                            id='btn-reset-anchor')
                        ]),
                        html.Br(),
                        # Spinner To Show Simulation Status
                        html.Div(
                            id='spinner',
                            children=
                            [
                                html.Img(src='data:image/gif;base64,{}'.format(spinner.decode())),
                                html.Label(
                                    id='spinner-label',
                                    children='Simualtion Progress: Pending....',
                                    style={'font-weight': 'bold', 'font-size': '16px', 'color': '#ffffff'}),
                            ], style={'display': 'none'},
                        ),

                    ], style={'marginBottom': 50, 'marginTop': 25, 'marginLeft':10, 'marginRight':10}),
                    width=3, style={'backgroundColor':'#0e2b63'}),
            
                dbc.Col(html.Div([
                    dcc.Tabs(id="tabs", value='tab-1', style={'height': tab_height},
                        children=[
                            dcc.Tab(label='Simulation Input', value='tab-1', style=tab_style, selected_style=tab_selected_style),
                            dcc.Tab(label='Simulation Output', value='tab-2', style=tab_style, selected_style=tab_selected_style),
                            dcc.Tab(label='Key Performance Indicators', value='tab-3', style=tab_style, selected_style=tab_selected_style),
                        ])
                    , html.Div(id='tabs-content', children=[layout_pricing_input.layout]) #Setting default pricing input
                ]), width=9)
            ]),

            # # Storing Components
            # html.Div(
            #     children=[dcc.Store(id="storage-pricing-input"),
            #             dcc.Store(id="storage-pricing-output")],
            # ),
            # Spinner Component & Storing Components

            dcc.Store(id='storage-pricing-output_all'),
            dcc.Store(id='storage-pricing-output_all_display'),
            dcc.Store(id='storage-pricing-output_display'),
            dcc.Loading(
                children=[dcc.Store(id="storage-pricing-input"),
                          dcc.Store(id="intermediate-value"),
                          dcc.Store(id="storage-pricing-output")],
                type="graph",
                fullscreen=True
            ),

            # Hidden Divs to Store Asynchronous Task related
            html.Div([
                #  hidden div to store celery background job task-id, task-status, and message-status
                html.Div(id='task-id',
                        children=None,
                        style={'display': 'none'}
                        ),
                #  hidden div to store celery background job task-status
                html.Div(id='task-status',
                        children=None,
                        style={'display': 'none'}
                        ),
                #  page refresh interval
                dcc.Interval(
                    id='task-refresh-interval',
                    interval=24*60*60*1*1000,  # in milliseconds
                    n_intervals=0
                ),
            ])
        ])