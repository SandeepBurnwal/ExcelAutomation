__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import pandas as pd
import dash_table as dt
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc

layout = html.Div([
            dbc.Row([
                dbc.Col([
                    dbc.Label("Simulation Input Type:"),
                    dbc.RadioItems(
                        options=[
                            {"label": "Manual Input", "value": "Manual Input"},
                            {"label": "Upload Input", "value": "Upload Input"}
                        ],
                        value="Manual Input",
                        id="radioitems-sim-input-type",
                        inline=True
                    )
                ])
            ],
            style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10}),
            
            dbc.Row([
                dbc.Col(html.A(dcc.Upload(
                                    id='upload-data',
                                    children=html.Div(['Drag and Drop Simulation Input Data']),
                                    style={'width': '100%','height': '60px','lineHeight': '60px','borderWidth': '1px','borderStyle': 'dashed', \
                                        'borderRadius': '5px','textAlign': 'center','margin': '10px'},
                                    # Allow multiple files to be uploaded is set to one
                                    multiple=False
                                ), id='upload-region-anchor'), width=9, style={'text-align':'center'}),
                dbc.Col(html.A(dbc.Button(
                                    "Download Template", 
                                    id='btn-template', 
                                    color="info", 
                                    className="mr-1"), 
                                    id='template-btn-anchor',
                                    href="", 
                                    download="Canada Pricing Template.csv", 
                                    target="_blank",
                                    style={'text-align':'center'}), width=3, style={'text-align':'center'}),
            ],
            style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10}),
           
            # dcc.Store inside the app that stores the intermediate value
            #dcc.Store(id='intermediate-value'),

            # New DataTable - SouthAfrica pricing ..
            dbc.Row([
                dbc.Col(dt.DataTable(
                            id='datatable-price',
                            style_header={
                                    'whiteSpace': 'normal',
                                    'backgroundColor': '#172962',
                                    'color': 'white'
                                },
                            style_table={
                                'height': 400,
                                'overflowX': 'scroll',
                                'overflowY': 'scroll'
                            },
                            style_cell={
                                'fontSize': '1.5vh',
                                'textAlign': 'center',
                                "color": "black"
                                },
                            columns=[],
                            page_current= 0,
                            page_size= 1000,
                            #page_action='custom',
                            #filter_action='custom',
                            #filter_query='',
                            #sort_action='custom',
                            #sort_mode='multi',
                            #sort_by=[]
                            ), align="center")
            ], 
            style={'marginBottom': 10, 'marginTop': 10, 'marginLeft':10, 'marginRight':10})
        ])