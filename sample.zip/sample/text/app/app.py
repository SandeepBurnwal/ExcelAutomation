__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import os
import sys
import logging, logging.config
import dash
import dash_bootstrap_components as dbc
from flask import Flask

# Normally Dash creates its own Flask server internally however
# by creating the server we can easily create routes for downloading files etc.
external_stylesheets = [dbc.themes.BOOTSTRAP]
server = Flask(__name__) 
app = dash.Dash(external_stylesheets=external_stylesheets, server=server)
app.config.suppress_callback_exceptions = True

