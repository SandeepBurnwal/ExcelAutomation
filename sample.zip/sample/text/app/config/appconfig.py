__author__ = "konwar.m"
__copyright__ = "Copyright 2021, BAT AI R&D"
__credits__ = ["konwar.m"]
__license__ = "BAT Ownership"
__version__ = "1.0.1"
__maintainer__ = "konwar.m"
__email__ = "manash_konwar@bat.com"
__status__ = "Development"

import os
import json
#os.chdir('D:/Project/Cross_market_dash/DataScienceSolutions/hub/solutions/marketing/pricing_solutions/south_africa/intelli_price/app/')

''' 
config_data_snowflakes, config_model_endpoints, config_model_picklefiles, ka_mapper_dict, brand_mapper_dict = None, None, None, None, None
try:
    with open(os.path.join('config','config_snowflakes.json')) as config_file:
        config_data_snowflakes = json.load(config_file)
except Exception as ex:
    print("Reading Snowflakes Configuration raised an exception: "+str(ex))

try:
    with open(os.path.join('config','config_modelendpoints.json')) as config_file:
        config_model_endpoints = json.load(config_file)
except Exception as ex:
    print("Reading Model Endpoint Configuration raised an exception: "+str(ex))

try:
    with open(os.path.join('config','config_modelpicklefiles.json')) as config_file:
        config_model_picklefiles = json.load(config_file)
except Exception as ex:
    print("Reading Model Pickle Configuration raised an exception: "+str(ex))

try:
    with open(os.path.join('config','mapper_brand.json')) as config_file:
        brand_mapper_dict = json.load(config_file)
except Exception as ex:
    print("Reading Brand Mapper Configuration raised an exception: "+str(ex))

class Config(object):
    DEBUG = False
    TESTING = False

class ProductionConfig(Config):
    SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND = config_data_snowflakes["login_outbound"]["login_credentials_generic"] if config_data_snowflakes is not None else {}
    SNOWFLAKE_LOGIN_CREDENTIALS_RAW = config_data_snowflakes["login_raw"]["login_credentials_generic"] if config_data_snowflakes is not None else {}
    PRICING_MODEL_ENDPOINTS = config_model_endpoints if config_model_endpoints is not None else {}
    PRICING_MODEL_PKLFILES = config_model_picklefiles if config_model_picklefiles is not None else {}
    BRAND_MAPPER_DICT = brand_mapper_dict if brand_mapper_dict is not None else {}
    
class TestingConfig(Config):
    TESTING = True

class DevelopmentConfig(Config):
    DEBUG = True

class DeploymentConfig(Config):
    SNOWFLAKE_LOGIN_CREDENTIALS_OUTBOUND = config_data_snowflakes["login_outbound"]["login_credentials_deployment"] if config_data_snowflakes is not None else {}
    SNOWFLAKE_LOGIN_CREDENTIALS_RAW = config_data_snowflakes["login_raw"]["login_credentials_generic"] if config_data_snowflakes is not None else {}
    PRICING_MODEL_ENDPOINTS = config_model_endpoints if config_model_endpoints is not None else {}
    PRICING_MODEL_PKLFILES = config_model_picklefiles if config_model_picklefiles is not None else {}
    BRAND_MAPPER_DICT = brand_mapper_dict if brand_mapper_dict is not None else {}

'''    