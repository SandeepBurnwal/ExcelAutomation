
end_point_uri = {
    "rest_api" : 'https://batmlrgmbradevjn6vw0.westeurope.cloudapp.azure.com:443/api/v1/service/rgm-br-model/score'
}

api_key = {
    "id" : 'lffZf87d3btClWN9gfVI7nd0H0JSQwpK'
}

tab_style = {
    'borderBottom': '1px solid #d6d6d6',
    'padding': '0',
    'fontWeight': 'bold',
    'line-height': '7vh'
}

tab_selected_style = {
    'borderTop': '1px solid #d6d6d6',
    'borderBottom': '1px solid #d6d6d6',
    'backgroundColor': '#FF7F7F',
    'color': 'white',
    'padding': '0',
    'line-height': '7vh'
}

month_int_text_mapping = {
    1: "1.0_Jan",
    2: "2.0_Feb",
    3: "3.0_Mar",
    4: "4.0_Apr",
    5: "5.0_May",
    6: "6.0_Jun",
    7: "7.0_Jul",
    8: "8.0_Aug",
    9: "9.0_Sep",
    10: "9.1_Oct",
    11: "9.2_Nov",
    12: "9.3_Dec"
}

final_model_col_list = {
    #"col_list" : ['YEAR', 'AVG_PRICE_20', 'STATE_Acre', 'STATE_Alagoas', 'STATE_AmapÃ¡', 'STATE_Amazonas', 'STATE_Bahia', 'STATE_CearÃ¡', 'STATE_Distrito Federal', 'STATE_EspÃ­rito Santo', 'STATE_GoiÃ¡s', 'STATE_MaranhÃ£o', 'STATE_Mato Grosso', 'STATE_Mato Grosso do Sul', 'STATE_Minas Gerais', 'STATE_ParanÃ¡', 'STATE_ParaÃ­ba', 'STATE_ParÃ¡', 'STATE_Pernambuco', 'STATE_PiauÃ­', 'STATE_Rio Grande do Norte', 'STATE_Rio Grande do Sul', 'STATE_Rio de Janeiro', 'STATE_RondÃ´nia', 'STATE_Roraima', 'STATE_Santa Catarina', 'STATE_Sergipe', 'STATE_SÃ£o Paulo', 'STATE_Tocantins', 'PLAYER_BAT', 'PLAYER_JTI', 'PLAYER_PMI', 'SEGMENT_ASPRM', 'SEGMENT_LOW', 'SEGMENT_PREMIUM', 'SEGMENT_Premium', 'SEGMENT_VFM', 'FAMILY_BELMONT', 'FAMILY_BENSON & HEDGES', 'FAMILY_CAMEL', 'FAMILY_CHANCELLER', 'FAMILY_CHESTERFIELD', 'FAMILY_DALLAS', 'FAMILY_DERBY', 'FAMILY_DUNHILL', 'FAMILY_FREE', 'FAMILY_HILTON', 'FAMILY_HOLLYWOOD', 'FAMILY_KENT', 'FAMILY_L&M', 'FAMILY_LUCKY', 'FAMILY_LUCKY STRIKE', 'FAMILY_LUXOR', 'FAMILY_MARLBORO', 'FAMILY_MINISTER', 'FAMILY_PARLIAMENT', 'FAMILY_PLAZA', 'FAMILY_RITZ', 'FAMILY_ROTHMANS', 'FAMILY_SAMPOERNA', 'FAMILY_SHELTON', 'FAMILY_VOGUE', 'FAMILY_WINSTON', 'PRICE_CLASS_BENSON & HEDGES', 'PRICE_CLASS_BENSON & HEDGES Mint', 'PRICE_CLASS_CHANCELLER', 'PRICE_CLASS_Camel Box', 'PRICE_CLASS_Camel DC Mint & Green', 'PRICE_CLASS_Camel DC Mint & Red', 'PRICE_CLASS_Camel MaÃ§o', 'PRICE_CLASS_Chanceller', 'PRICE_CLASS_Chesterfield Box', 'PRICE_CLASS_Chesterfield MaÃ§o', 'PRICE_CLASS_Chesterfield Remix', 'PRICE_CLASS_DALLAS CLASSIC HL', 'PRICE_CLASS_DERBY HL', 'PRICE_CLASS_DERBY SC', 'PRICE_CLASS_DUNHILL FINE CUT', 'PRICE_CLASS_Derby', 'PRICE_CLASS_Derby HL', 'PRICE_CLASS_Derby Mini', 'PRICE_CLASS_Derby Refil', 'PRICE_CLASS_Derby SC', 'PRICE_CLASS_Dunhill BOX', 'PRICE_CLASS_Dunhill DC', 'PRICE_CLASS_Dunhill Fine Cut', 'PRICE_CLASS_Dunhill HL', 'PRICE_CLASS_Dunhill SC', 'PRICE_CLASS_Dunhill SLS', 'PRICE_CLASS_Free HL', 'PRICE_CLASS_Free SC', 'PRICE_CLASS_Hilton', 'PRICE_CLASS_Hilton KS', 'PRICE_CLASS_Hilton KS HL', 'PRICE_CLASS_Hilton KS SC', 'PRICE_CLASS_Hilton SLS', 'PRICE_CLASS_Hilton SLS HL', 'PRICE_CLASS_Hilton SLS SC', 'PRICE_CLASS_Hollywood', 'PRICE_CLASS_Hollywood Caps', 'PRICE_CLASS_Hollywood HL', 'PRICE_CLASS_Hollywood SC', 'PRICE_CLASS_KENT HL', 'PRICE_CLASS_Kent Boost', 'PRICE_CLASS_Kent Control & Boost + Control', 'PRICE_CLASS_Kent Control + Boost', 'PRICE_CLASS_Kent HL', 'PRICE_CLASS_Kent SC', 'PRICE_CLASS_L&M', 'PRICE_CLASS_L&M Black Ice', 'PRICE_CLASS_L&M Vibe', 'PRICE_CLASS_LUXOR', 'PRICE_CLASS_Lucky Strike', 'PRICE_CLASS_Lucky Strike C&R', 'PRICE_CLASS_Lucky Strike DC', 'PRICE_CLASS_Luxor', 'PRICE_CLASS_Marboloro DC', 'PRICE_CLASS_Marlboro Blue Ice', 'PRICE_CLASS_Marlboro Box', 'PRICE_CLASS_Marlboro Filter Plus', 'PRICE_CLASS_Marlboro Gold', 'PRICE_CLASS_Marlboro Gold Box', 'PRICE_CLASS_Marlboro MaÃ§o', 'PRICE_CLASS_Minister', 'PRICE_CLASS_Minister Fresh Ice', 'PRICE_CLASS_Minister HL', 'PRICE_CLASS_Minister SC', 'PRICE_CLASS_PARLIAMENT', 'PRICE_CLASS_Parliament', 'PRICE_CLASS_Plaza', 'PRICE_CLASS_Plaza KS', 'PRICE_CLASS_Plaza SLS', 'PRICE_CLASS_Ritz', 'PRICE_CLASS_Rothmans HL', 'PRICE_CLASS_Rothmans SC', 'PRICE_CLASS_Sampoerna SLS', 'PRICE_CLASS_Sampoerna SLS F&S', 'PRICE_CLASS_Shelton KS', 'PRICE_CLASS_Shelton SLS', 'PRICE_CLASS_Vogue', 'PRICE_CLASS_Winston HL', 'PRICE_CLASS_Winston Purple & Exotic Mint', 'PRICE_CLASS_Winston SR']
    "col_list" : ['YEAR', 'AVG_PRICE_20', 'STATE_Acre', 'STATE_Alagoas', 'STATE_Amapá', 'STATE_Amazonas', 'STATE_Bahia', 'STATE_Ceará', 'STATE_Distrito Federal', 'STATE_Espírito Santo', 'STATE_Goiás', 'STATE_Maranhão', 'STATE_Mato Grosso', 'STATE_Mato Grosso do Sul', 'STATE_Minas Gerais', 'STATE_Other', 'STATE_Paraná', 'STATE_Paraíba', 'STATE_Pará', 'STATE_Pernambuco', 'STATE_Piauí', 'STATE_Rio Grande do Norte', 'STATE_Rio Grande do Sul', 'STATE_Rio de Janeiro', 'STATE_Rondônia', 'STATE_Roraima', 'STATE_Santa Catarina', 'STATE_Sergipe', 'STATE_São Paulo', 'STATE_Tocantins', 'PLAYER_BAT', 'PLAYER_DNP', 'PLAYER_JTI', 'PLAYER_PMI', 'SEGMENT_ASPRM', 'SEGMENT_DNP', 'SEGMENT_LOW', 'SEGMENT_PREMIUM', 'SEGMENT_Premium', 'SEGMENT_VFM', 'FAMILY_BELMONT', 'FAMILY_BENSON & HEDGES', 'FAMILY_CAMEL', 'FAMILY_CHANCELLER', 'FAMILY_CHESTERFIELD', 'FAMILY_DALLAS', 'FAMILY_DERBY', 'FAMILY_DNP', 'FAMILY_DUNHILL', 'FAMILY_FREE', 'FAMILY_HILTON', 'FAMILY_HOLLYWOOD', 'FAMILY_KENT', 'FAMILY_L&M', 'FAMILY_LUCKY', 'FAMILY_LUCKY STRIKE', 'FAMILY_LUXOR', 'FAMILY_MARLBORO', 'FAMILY_MINISTER', 'FAMILY_PARLIAMENT', 'FAMILY_PLAZA', 'FAMILY_RITZ', 'FAMILY_ROTHMANS', 'FAMILY_SAMPOERNA', 'FAMILY_SHELTON', 'FAMILY_VOGUE', 'FAMILY_WINSTON', 'PRICE_CLASS_BENSON & HEDGES', 'PRICE_CLASS_BENSON & HEDGES Mint', 'PRICE_CLASS_CHANCELLER', 'PRICE_CLASS_Camel Box', 'PRICE_CLASS_Camel DC Mint & Green', 'PRICE_CLASS_Camel DC Mint & Red', 'PRICE_CLASS_Camel Maço', 'PRICE_CLASS_Chanceller', 'PRICE_CLASS_Chesterfield Box', 'PRICE_CLASS_Chesterfield Maço', 'PRICE_CLASS_Chesterfield Remix', 'PRICE_CLASS_DALLAS CLASSIC HL', 'PRICE_CLASS_DERBY HL', 'PRICE_CLASS_DERBY SC', 'PRICE_CLASS_DNP', 'PRICE_CLASS_DUNHILL FINE CUT', 'PRICE_CLASS_Derby', 'PRICE_CLASS_Derby HL', 'PRICE_CLASS_Derby Mini', 'PRICE_CLASS_Derby Refil', 'PRICE_CLASS_Derby SC', 'PRICE_CLASS_Dunhill BOX', 'PRICE_CLASS_Dunhill DC', 'PRICE_CLASS_Dunhill Fine Cut', 'PRICE_CLASS_Dunhill HL', 'PRICE_CLASS_Dunhill SC', 'PRICE_CLASS_Dunhill SLS', 'PRICE_CLASS_Free HL', 'PRICE_CLASS_Free SC', 'PRICE_CLASS_Hilton', 'PRICE_CLASS_Hilton KS', 'PRICE_CLASS_Hilton KS HL', 'PRICE_CLASS_Hilton KS SC', 'PRICE_CLASS_Hilton SLS', 'PRICE_CLASS_Hilton SLS HL', 'PRICE_CLASS_Hilton SLS SC', 'PRICE_CLASS_Hollywood', 'PRICE_CLASS_Hollywood Caps', 'PRICE_CLASS_Hollywood HL', 'PRICE_CLASS_Hollywood SC', 'PRICE_CLASS_KENT HL', 'PRICE_CLASS_Kent Boost', 'PRICE_CLASS_Kent Control & Boost + Control', 'PRICE_CLASS_Kent Control + Boost', 'PRICE_CLASS_Kent HL', 'PRICE_CLASS_Kent SC', 'PRICE_CLASS_L&M', 'PRICE_CLASS_L&M Black Ice', 'PRICE_CLASS_L&M Vibe', 'PRICE_CLASS_LUXOR', 'PRICE_CLASS_Lucky Strike', 'PRICE_CLASS_Lucky Strike C&R', 'PRICE_CLASS_Lucky Strike DC', 'PRICE_CLASS_Luxor', 'PRICE_CLASS_Marboloro DC', 'PRICE_CLASS_Marlboro Blue Ice', 'PRICE_CLASS_Marlboro Box', 'PRICE_CLASS_Marlboro Filter Plus', 'PRICE_CLASS_Marlboro Gold', 'PRICE_CLASS_Marlboro Gold Box', 'PRICE_CLASS_Marlboro Maço', 'PRICE_CLASS_Minister', 'PRICE_CLASS_Minister Fresh Ice', 'PRICE_CLASS_Minister HL', 'PRICE_CLASS_Minister SC', 'PRICE_CLASS_PARLIAMENT', 'PRICE_CLASS_Parliament', 'PRICE_CLASS_Plaza', 'PRICE_CLASS_Plaza KS', 'PRICE_CLASS_Plaza SLS', 'PRICE_CLASS_Ritz', 'PRICE_CLASS_Rothmans HL', 'PRICE_CLASS_Rothmans SC', 'PRICE_CLASS_Sampoerna SLS', 'PRICE_CLASS_Sampoerna SLS F&S', 'PRICE_CLASS_Shelton KS', 'PRICE_CLASS_Shelton SLS', 'PRICE_CLASS_Vogue', 'PRICE_CLASS_Winston HL', 'PRICE_CLASS_Winston Purple & Exotic Mint', 'PRICE_CLASS_Winston SR']
}