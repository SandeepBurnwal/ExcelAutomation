import numpy as np
import os
import seaborn as sns
import altair as alt
import matplotlib.pyplot as plt
import snowflake.connector
import plotly
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dateutil.relativedelta import relativedelta
import datetime
from datetime import datetime
import sklearn
from sklearn.metrics import mean_absolute_error as mae
import warnings 
warnings.filterwarnings('ignore')
warnings.filterwarnings('ignore', category=DeprecationWarning)

from azureml.core.workspace import Workspace
from azureml.core.experiment import Experiment
from azureml.core.dataset import Dataset
from azureml.core.compute import ComputeTarget, AmlCompute
from azureml.core.compute_target import ComputeTargetException
from azureml.train.automl import AutoMLConfig
from azureml.automl.core.featurization import FeaturizationConfig
from azureml.core.authentication import AzureCliAuthentication

def main():
    # Pull the data for trining the model training ..
    Data, Pre_Calculated = process_data()
    
    # Train the model here using the data prepared using the above function 
    cls = train_model(Data)

    # Save the model file as pickle file 
    #------------------------------------
    joblib.dump(value = cls, filename="./price_simulator.pkl")


    # Register the model file(pickle file) into the Azure workspace. Next using the scoring scipt, an end point api will be created 
    #----------------------------------------------------------------
    '''
    ##Create run/experiment 
	ws = Workspace(
		   subscription_id="62139dec-4b9a-4661-8448-b84bf8cc354b",
		   resource_group="rg-pd-ne-edp-datascience-dev-01",
		   workspace_name="batmlw-pd-we-edp-rgm-brz-dev"
		   )

    path_var = os.getcwd() + "/price_simulator.pkl"
    print(path_var)

    model = Model.register(workspace = ws, model_name="price_simulator_sa",
    model_path=path_var)
    print(model.name, model.id, model.version, sep='\t')
    '''
#############################################################################################################################


if __name__ == "__main__":
    main()