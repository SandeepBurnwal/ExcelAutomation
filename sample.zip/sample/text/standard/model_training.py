import numpy as np
import os
import seaborn as sns
import altair as alt
import matplotlib.pyplot as plt
import snowflake.connector
import plotly
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dateutil.relativedelta import relativedelta
import datetime
from datetime import datetime
import sklearn
from sklearn.metrics import mean_absolute_error as mae
import warnings 
warnings.filterwarnings('ignore')
warnings.filterwarnings('ignore', category=DeprecationWarning)

from azureml.core.workspace import Workspace
from azureml.core.experiment import Experiment
from azureml.core.dataset import Dataset
from azureml.core.compute import ComputeTarget, AmlCompute
from azureml.core.compute_target import ComputeTargetException
from azureml.train.automl import AutoMLConfig
from azureml.automl.core.featurization import FeaturizationConfig
from azureml.core.authentication import AzureCliAuthentication
## =======================================================================================================

def train_model(finance_data):
    # Model Training 
    Model_Data = finance_data[['STATE', 'PLAYER', 'SEGMENT', 'FAMILY',
       'PRICE_CLASS', 'YEAR', 'AVG_PRICE_20', 
       'SALES_VOLUME']]

    Categorical_Columns = ['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS','YEAR']

    print('There were {} columns before encoding categorical features'.format(Model_Data.shape[1]))
    Model_Data = oneHotEncode(Model_Data, Categorical_Columns)
    print('There are {} columns after encoding categorical features'.format(Model_Data.shape[1]))

    # Train Test Split
    # -----------------------
    Y_Var = ['SALES_VOLUME']

    #separating independent and dependent variable
    X = Model_Data.drop(columns=Y_Var, axis=1)
    y = Model_Data[Y_Var]

    # Model Training Random Forest model execution, due to the quantum of data boosting will take lot of time so we'll not use any Boosting method. Neural Network results in low accuracy and high training time
    best_param_qr = {'bootstrap': True, 'max_depth': 110, 'min_samples_leaf': 3, 'min_samples_split': 8, 'n_estimators': 200}

    cls = RandomForestRegressor(n_estimators=best_param_qr['n_estimators'], max_depth=best_param_qr['max_depth'],
                                bootstrap = best_param_qr['bootstrap'], min_samples_leaf=best_param_qr['min_samples_leaf'], 
                                min_samples_split=best_param_qr['min_samples_split'])

    cls.fit(X, y)
    return cls    
######################################################################################################################
