from sklearn.model_selection import train_test_split
import os
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.externals import joblib
import urllib.request
from azureml.core.model import Model
import pandas as pd
import numpy as np
import seaborn as sns
import altair as alt
import matplotlib.pyplot as plt
import snowflake.connector
import plotly
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dateutil.relativedelta import relativedelta
import datetime
from datetime import datetime
import sklearn
from sklearn.metrics import mean_absolute_error as mae
import warnings 
warnings.filterwarnings('ignore')
warnings.filterwarnings('ignore', category=DeprecationWarning)

from azureml.core.workspace import Workspace
from azureml.core.experiment import Experiment
from azureml.core.dataset import Dataset
from azureml.core.compute import ComputeTarget, AmlCompute
from azureml.core.compute_target import ComputeTargetException
from azureml.train.automl import AutoMLConfig
from azureml.automl.core.featurization import FeaturizationConfig
from azureml.core.authentication import AzureCliAuthentication


def process_data():
    '''
    1. First part ==> Snowflake connection and extraction of data based on query
    2. Second part ==> Basic data pre-processing 
    3. Third part ==> Pre-calculated feature engineering. [To be stored in Snowflake]  
    '''


    ''' Connect to Snowflake, pull the data and do the preprocessing here  '''
    finance_data = data_load_snowflake('RGM_BRA_DEV_SERVICE_USER',
                                    '9MZeZKa8DktKrHKj',
                                    'fx54096.west-europe.azure',
                                    "BRA_DEV_PRESENTATION_ADHOC_WH",
                                    "BRA_DEV_DATASCIENCE",
                                    "PRI_SIM",
                                    'https',
                                    'select * from BRA_DEV_DATASCIENCE.PRI_SIM.VW_PRICE_CLASS_DNP_DP7')
    
    Data = finance_data

    # Excluding covid data after 2020 and 2021 
    finance_data = finance_data[~(finance_data.YEAR.isin(["2020","2021"]))]

    # Dropping duplicates 
    finance_data = finance_data.drop_duplicates()

    # Replacing missing with other 
    
    finance_data['STATE'] = finance_data['STATE'].fillna("Other")
    
    finance_data['CAPITAL'] = finance_data['CAPITAL'].fillna("Other")
    
    finance_data['TERRITORY'] = finance_data['TERRITORY'].fillna("Other")
	
	# Standarizing values in date column
    conditions = [
		((finance_data['MONTH'] == 'Jan') | (finance_data['MONTH'] == 'Janeiro' )|(finance_data['MONTH'] == '1') ),
		((finance_data['MONTH'] == 'Feb') | (finance_data['MONTH'] == 'Fevereiro')|(finance_data['MONTH'] == '2') |(finance_data['MONTH'] == 'Fev')),
		((finance_data['MONTH'] == 'Mar') | (finance_data['MONTH'] == 'Março')|(finance_data['MONTH'] == '3')),
		((finance_data['MONTH'] == 'Apr') | (finance_data['MONTH'] == 'Abril')|(finance_data['MONTH'] == '4') |(finance_data['MONTH'] == 'Abr')),
		((finance_data['MONTH'] == 'May') | (finance_data['MONTH'] == 'Maio') |(finance_data['MONTH'] == '5')|(finance_data['MONTH'] == 'Mai')),
		((finance_data['MONTH'] == 'Jun') | (finance_data['MONTH'] == 'Junho')|(finance_data['MONTH'] == '6')),
		((finance_data['MONTH'] == 'Jul') | (finance_data['MONTH'] == 'Julho') |(finance_data['MONTH'] == '7')),
		((finance_data['MONTH'] == 'Aug') | (finance_data['MONTH'] == 'Agosto') |(finance_data['MONTH'] == '8')|(finance_data['MONTH'] == 'Ago')),
		((finance_data['MONTH'] == 'Sep') | (finance_data['MONTH'] == 'Setembro') |(finance_data['MONTH'] == '9')|(finance_data['MONTH'] == 'Set')),
		((finance_data['MONTH'] == 'Oct') | (finance_data['MONTH'] == 'Outubro') |(finance_data['MONTH'] == '10')|(finance_data['MONTH'] == 'Out')),
		((finance_data['MONTH'] == 'Nov') | (finance_data['MONTH'] == 'Novembro')|(finance_data['MONTH'] == '11')),
		((finance_data['MONTH'] == 'Dec') | (finance_data['MONTH'] == 'Dezembro')|(finance_data['MONTH'] == '12') |(finance_data['MONTH'] == 'Dez'))
		]
        
    choices = [1,2,3,4,5,6,7,8,9,10,11,12]
    
    finance_data['Month_Sequence'] = np.select(conditions, choices, default=13)
	
	## Creating date column from month and year column as first day of every month 
    finance_data['YEAR'] = finance_data['YEAR'].astype(int)
    finance_data['Date_Column']=pd.to_datetime((finance_data.YEAR*10000+finance_data.Month_Sequence*100+1).apply(str),format='%Y%m%d')
	
	# Removing rows where price class is a number
    finance_data_price_class=finance_data[pd.to_numeric(finance_data['PRICE_CLASS'], errors='coerce').isnull()]
    finance_data.shape[0] - finance_data_price_class.shape[0]
    finance_data=finance_data_price_class
	
	#Number of times price changed
    unique_data = finance_data.groupby("PRICE_CLASS").agg({"AVG_PRICE_20":pd.Series.nunique})
    unique_data=unique_data.reset_index()
    intial_count=unique_data.PRICE_CLASS.nunique()
    unique_data_filter=unique_data[unique_data.AVG_PRICE_20>=10]
    final_count=unique_data_filter.PRICE_CLASS.nunique()
    pre_num_records=finance_data.shape[0]
    finance_data = finance_data[finance_data["PRICE_CLASS"].isin(unique_data_filter.PRICE_CLASS)]
    finance_data_original_form=finance_data
    
    finance_data['QUARTER'] = ((finance_data['Month_Sequence']-1)//3)+1
    
    finance_data['YEAR_MONTH'] = finance_data['YEAR'].astype(str) + "_" + finance_data['Month_Sequence'].astype(str)
    finance_data['YEAR_MONTH'] = np.where(finance_data['YEAR_MONTH'].str.len() == 7,finance_data['YEAR_MONTH'],
    finance_data['YEAR_MONTH'].str[:5] + "0" + finance_data['YEAR_MONTH'].str[5:])
	
	# Exclude current year month data
    currentMonth = datetime.now().month
    currentYear = datetime.now().year
    if (currentMonth < 10):
        currentYearMonth = str(currentYear) + "_0" + str(currentMonth)
    else:
        currentYearMonth = str(currentYear) + "_" + str(currentMonth)
    print(currentYearMonth)
    
    finance_data = finance_data[~(finance_data['YEAR_MONTH'] == currentYearMonth)]
	
	# Precalculated
    Pre_Calculated = Data[['STATE', 'PLAYER', 'SEGMENT', 'FAMILY','PRICE_CLASS']].drop_duplicates()
    Pre_Calculated['KEY'] = 'join'
    
    Duration = pd.DataFrame(columns = ['YEAR','MONTH'], dtype='int64')
    first = datetime(datetime.now().year, datetime.now().month, 1)
    
    for i in range(9):
        new_row = {'YEAR':(first + pd.offsets.MonthBegin(i+1)).year, 
        'MONTH':(first + pd.offsets.MonthBegin(i+1)).month}
        Duration = Duration.append(new_row, ignore_index=True)
    Duration['YEAR_MONTH'] = Duration['YEAR'].astype(str) + "_" + Duration['MONTH'].astype(str)
    Duration['YEAR_MONTH'] = np.where(Duration['YEAR_MONTH'].str.len() == 7,Duration['YEAR_MONTH'],
    Duration['YEAR_MONTH'].str[:5] + "0" + Duration['YEAR_MONTH'].str[5:])
    Duration['QUARTER'] = ((Duration['MONTH']-1)//3)+1
    Duration['KEY'] = 'join'
    
    Pre_Calculated = pd.merge(Pre_Calculated, Duration, how='inner', on='KEY')
    
    Pre_Calculated = lag_function(Data, ['STATE', 'PLAYER', 'SEGMENT', 'FAMILY','PRICE_CLASS'], ['YEAR', 'MONTH'], Pre_Calculated, 'AVG_PRICE_20')
    
    Pre_Calculated = Pre_Calculated[['STATE', 'PLAYER', 'SEGMENT', 'FAMILY', 'PRICE_CLASS', 'YEAR','MONTH', 'QUARTER','AVG_PRICE_20']]
    
    return finance_data, Pre_Calculated   
####################################################################################


''' Connect to Snowflake and pull the data based on the input query '''
#Connect with data source 
def data_load_snowflake(user,password,account,warehouse,database,schema,protocol,query_string):
	ctx = snowflake.connector.connect(
		user=user,
		password=password,
		account=account
		)
	cs = ctx.cursor()
	try:
		cs.execute("SELECT current_version()")
		one_row = cs.fetchone()
		print(one_row[0])
	finally:
		cs.close()
	ctx.close()

	# Read data from finance table into pandas dataframe 
	ctx = snowflake.connector.connect(
			#   host=host,
			  user=user,
			  password=password,
			  account=account,
			  warehouse=warehouse,
			  database=database,
			  schema=schema,
			  protocol=protocol,
			#   port=443
			)


	cur = ctx.cursor()

	# Execute statement that will generate a result set.
	sql = query_string
	cur.execute(sql)

	# # Fetch the result set from the cursor and deliver it as the Pandas DataFrame.
	finance_data = cur.fetch_pandas_all()
	
	return finance_data
####################################################################################

def lag_function(source_data, source_level, duration_level, destination_data, column):
    sort_selection  = source_level + duration_level
    selection = sort_selection + [column]
    lag_data = source_data[selection]
    lag_data = lag_data.sort_values(by=sort_selection)
    lag_data = lag_data.groupby(source_level, as_index=False).tail(1)
    lag_data.drop(columns=duration_level, inplace=True, axis=1)
    destination_data = pd.merge(destination_data, lag_data, how='left', on=source_level)
    return destination_data
############################################################################################################


def oneHotEncode(df,colNames):
    for col in colNames:
        if( df[col].dtype == np.dtype('object')):
            dummies = pd.get_dummies(df[col],prefix=col)
            df = pd.concat([df,dummies],axis=1)

            #drop the encoded column
            df.drop([col],axis = 1 , inplace=True)
    return df
###################################################################################################
